package net.createmod.catnip.platform;

import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import org.jetbrains.annotations.Nullable;
import dev.engine_room.flywheel.lib.model.baked.EmptyVirtualBlockGetter;
import net.createmod.catnip.client.render.model.ShadeSeparatedBufferSource;
import net.createmod.catnip.client.render.model.ShadeSeparatedResultConsumer;
import net.createmod.catnip.impl.client.render.model.BakedModelBuffererImpl;
import net.createmod.catnip.platform.services.ModClientHooksHelper;
import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.createmod.catnip.theme.Color;
import net.createmod.ponder.mixin.client.accessor.ParticleEngineAccessor;
import net.createmod.ponder.render.ForgeShadedBlockSbbBuilder;
import net.createmod.ponder.render.VirtualRenderHelper;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.World;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraftforge.client.model.data.ModelData;

public class ForgeClientHooksHelper implements ModClientHooksHelper {
	private final Map<Identifier, ParticleFactory<?>> particleProviders = ((ParticleEngineAccessor) MinecraftClient.getInstance().particleEngine).ponder$getProviders();

	@Override
	public Locale getCurrentLocale() {
		return MinecraftClient.getInstance().getLanguageManager().getJavaLocale();
	}

	@Override
	@Nullable
	@SuppressWarnings("unchecked")
	public <T extends ParticleEffect> Particle createParticleFromData(T data, ClientWorld level, double x, double y,
																	   double z, double mx, double my, double mz) {
		Identifier key = CatnipServices.REGISTRIES.getKeyOrThrow(data.getType());
		ParticleFactory<T> particleProvider = (ParticleFactory<T>) particleProviders.get(key);
		return particleProvider == null ? null : particleProvider.createParticle(data, level, x, y, z, mx, my, mz);
	}

	@Override
	public MinecraftClient getMinecraftFromScreen(Screen screen) {
		return screen.getMinecraft();
	}

	@Override
	public boolean isKeyPressed(KeyBinding mapping) {
		int keyCode = mapping.getKey().getValue();
		long window = MinecraftClient.getInstance().getWindow().getWindow();
		return InputUtil.isKeyDown(window, keyCode) && mapping.isConflictContextAndModifierActive();
	}

	@Override
	public void enableStencilBuffer(Framebuffer renderTarget) {
		renderTarget.enableStencil();
	}

	@Override
	public void renderFullFluidState(MatrixStack ms, VertexConsumerProvider.Immediate buffer, FluidState fluid) {
		CatnipServices.FLUID_RENDERER.renderFluidBox(fluid, 0, 0, 0, 1, 1, 1, buffer, ms, LightTexture.FULL_BRIGHT, false, true);
	}

	@Override
	public void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedBufferSource bufferSource) {
		BakedModelBuffererImpl.bufferModel(model, pos, level, state, poseStack, null, bufferSource);
	}

	@Override
	public void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedResultConsumer resultConsumer) {
		BakedModelBuffererImpl.bufferModel(model, pos, level, state, poseStack, null, resultConsumer);
	}

	@Override
	public void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedBufferSource bufferSource) {
		BakedModelBuffererImpl.bufferBlocks(posIterator, level, poseStack, null, renderFluids, bufferSource);
	}

	@Override
	public void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedResultConsumer resultConsumer) {
		BakedModelBuffererImpl.bufferBlocks(posIterator, level, poseStack, null, renderFluids, resultConsumer);
	}

	//

	@Override
	public ShadedBlockSbbBuilder createSbbBuilder(BufferBuilder builder) {
		return new ForgeShadedBlockSbbBuilder(builder);
	}

	@Override
	public Iterable<RenderLayer> getRenderTypesForBlockModel(BlockState state, Random random,
															@Nullable BlockEntity beWithModelData) {
		BakedModel model = MinecraftClient.getInstance().getBlockRenderer().getBlockModel(state);
		ModelData modelData = beWithModelData != null ? beWithModelData.getModelData() : ModelData.EMPTY;
		return model.getRenderTypes(state, random, modelData);
	}

	@Override
	public boolean doesBlockModelContainRenderType(RenderLayer layer, BlockState state, Random random,
												   @Nullable BlockEntity beWithModelData) {
		BakedModel model = MinecraftClient.getInstance().getBlockRenderer().getBlockModel(state);
		ModelData modelData = beWithModelData != null ? beWithModelData.getModelData() : ModelData.EMPTY;
		return model.getRenderTypes(state, random, modelData).contains(layer);
	}

	@Override
	public void tesselateBlockVirtual(BlockRenderManager dispatcher, BakedModel model, BlockState state, BlockPos pos, MatrixStack poseStack, VertexConsumer consumer, boolean checkSides, Random randomSource, long seed, int packedOverlay, @Nullable RenderLayer renderType) {
		BlockModelRenderer modelRenderer = dispatcher.getModelRenderer();
		ModelData modelData = model.getModelData(EmptyVirtualBlockGetter.FULL_DARK, pos, state, VirtualRenderHelper.VIRTUAL_DATA);
		modelRenderer.tesselateBlock(EmptyVirtualBlockGetter.FULL_DARK, model, state, pos, poseStack, consumer, checkSides, randomSource, seed, packedOverlay, modelData, renderType);
	}

	@Override
	public void tesselateBlockVirtual(World level, BlockRenderManager dispatcher, BakedModel model, BlockState state, BlockPos pos, MatrixStack poseStack, VertexConsumer consumer, boolean checkSides, Random randomSource, long seed, int packedOverlay, @Nullable RenderLayer renderType) {
		BlockModelRenderer modelRenderer = dispatcher.getModelRenderer();
		BlockEntity blockEntity = level.getBlockEntity(pos);
		ModelData modelData = model.getModelData(level, pos, state, blockEntity == null ? ModelData.EMPTY : blockEntity.getModelData());
		modelRenderer.tesselateBlock(level, model, state, pos, poseStack, consumer, checkSides, randomSource, seed, packedOverlay, modelData, renderType);
	}

	@Override
	public void renderGuiGameElementModel(BlockRenderManager blockRenderer, VertexConsumerProvider.Immediate buffer,
										  MatrixStack ms, BlockState blockState, BakedModel blockModel, int color, @Nullable BlockEntity beWithModelData) {
		ModelData modelData = beWithModelData != null ? beWithModelData.getModelData() : VirtualRenderHelper.VIRTUAL_DATA;

		if (blockState.getBlock() == Blocks.AIR) {
			RenderLayer renderType = TexturedRenderLayers.translucentCullBlockSheet();
			blockRenderer.getModelRenderer().renderModel(ms.last(), buffer.getBuffer(renderType), blockState,
														 blockModel, 1, 1, 1, LightTexture.FULL_BRIGHT,
														 OverlayTexture.NO_OVERLAY, modelData, null);
		} else {
			int blockColor = MinecraftClient.getInstance().getBlockColors().getColor(blockState, null, null, 0);
			Color rgb = new Color(blockColor == -1 ? color : blockColor);

			for (RenderLayer chunkType : blockModel.getRenderTypes(blockState, Random.create(42L),
																  VirtualRenderHelper.VIRTUAL_DATA)) {
				RenderLayer renderType = RenderTypeHelper.getEntityRenderType(chunkType, true);
				blockRenderer.getModelRenderer().renderModel(ms.last(), buffer.getBuffer(renderType), blockState,
															 blockModel, rgb.getRedAsFloat(), rgb.getGreenAsFloat(),
															 rgb.getBlueAsFloat(), LightTexture.FULL_BRIGHT,
															 OverlayTexture.NO_OVERLAY, modelData, chunkType);
			}
		}
	}

	@Override
	public void renderVirtualBlockStateModel(BlockRenderManager dispatcher, MatrixStack ms, VertexConsumer consumer,
											 BlockState state, BakedModel model, float red, float green, float blue,
											 RenderLayer layer) {
		dispatcher.getModelRenderer().renderModel(ms.last(), consumer, state, model, red, green, blue,
			LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
			VirtualRenderHelper.VIRTUAL_DATA, layer);
	}

	@Override
	public void vertexConsumerPutBulkDataWithAlpha(VertexConsumer consumer, MatrixStack.Entry pose, BakedQuad quad,
												   float red, float green, float blue, float alpha, int packedLight,
												   int packedOverlay) {
		consumer.putBulkData(pose, quad, red, green, blue, alpha, packedLight, packedOverlay, true);
	}
}
