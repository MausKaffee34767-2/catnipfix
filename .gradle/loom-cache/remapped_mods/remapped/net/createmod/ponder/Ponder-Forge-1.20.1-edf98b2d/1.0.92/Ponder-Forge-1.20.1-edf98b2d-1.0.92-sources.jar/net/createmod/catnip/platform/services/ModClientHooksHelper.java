package net.createmod.catnip.platform.services;

import java.util.Iterator;
import java.util.Locale;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import net.createmod.catnip.client.render.model.ShadeSeparatedBufferSource;
import net.createmod.catnip.client.render.model.ShadeSeparatedResultConsumer;
import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.World;

public interface ModClientHooksHelper {
	Locale getCurrentLocale();

	@Nullable
	<T extends ParticleEffect> Particle createParticleFromData(T data, ClientWorld level, double x, double y, double z,
																double mx, double my, double mz);

	MinecraftClient getMinecraftFromScreen(Screen screen);

	// note: implementations don't use isDown since we need this to work inside screens
	boolean isKeyPressed(KeyBinding mapping);

	void enableStencilBuffer(Framebuffer renderTarget);

	void renderFullFluidState(MatrixStack ms, VertexConsumerProvider.Immediate buffer, FluidState fluid);

	@ApiStatus.Internal
	void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedBufferSource bufferSource);

	@ApiStatus.Internal
	void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedResultConsumer resultConsumer);

	@ApiStatus.Internal
	void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedBufferSource bufferSource);

	@ApiStatus.Internal
	void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedResultConsumer resultConsumer);

	@Deprecated(forRemoval = true)
	default ShadedBlockSbbBuilder createSbbBuilder(BufferBuilder builder) {
		return new ShadedBlockSbbBuilder(builder);
	}

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	Iterable<RenderLayer> getRenderTypesForBlockModel(BlockState state, Random random,
													 @Nullable BlockEntity beWithModelData);

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	boolean doesBlockModelContainRenderType(RenderLayer layer, BlockState state, Random random,
											@Nullable BlockEntity beWithModelData);

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	void tesselateBlockVirtual(BlockRenderManager dispatcher, BakedModel model, BlockState state, BlockPos pos, MatrixStack poseStack, VertexConsumer consumer, boolean checkSides, Random randomSource, long seed, int packedOverlay, RenderLayer renderType);

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	default void tesselateBlockVirtual(World level, BlockRenderManager dispatcher, BakedModel model, BlockState state, BlockPos pos, MatrixStack poseStack, VertexConsumer consumer, boolean checkSides, Random randomSource, long seed, int packedOverlay, RenderLayer renderType) {
		tesselateBlockVirtual(dispatcher, model, state, pos, poseStack, consumer, checkSides, randomSource, seed, packedOverlay, renderType);
	}

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	void renderGuiGameElementModel(BlockRenderManager blockRenderer, VertexConsumerProvider.Immediate buffer,
								   MatrixStack ms, BlockState state, BakedModel blockModel, int color, @Nullable BlockEntity beWithModelData);

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	default void renderGuiGameElementModel(BlockRenderManager blockRenderer, VertexConsumerProvider.Immediate buffer,
								   MatrixStack ms, BlockState state, BakedModel blockModel, int color) {
		renderGuiGameElementModel(blockRenderer, buffer, ms, state, blockModel, color, null);
	}

	/** <b>BROKEN - DO NOT USE</b> */
	@Deprecated(forRemoval = true)
	void renderVirtualBlockStateModel(BlockRenderManager dispatcher, MatrixStack ms, VertexConsumer consumer,
									  BlockState state, BakedModel model, float red, float green, float blue,
									  RenderLayer layer);

	@Deprecated(forRemoval = true)
	void vertexConsumerPutBulkDataWithAlpha(VertexConsumer consumer, MatrixStack.Entry pose, BakedQuad quad, float red,
											float green, float blue, float alpha, int packedLight, int packedOverlay);

	@Deprecated(forRemoval = true)
	default BlockRenderManager getBlockRenderDispatcher() {
		return MinecraftClient.getInstance().getBlockRenderer();
	}

	@Deprecated(forRemoval = true)
	default boolean chunkRenderTypeMatches(BlockState state, RenderLayer layer) {
		return RenderLayers.getChunkRenderType(state) == layer;
	}

	@Deprecated(forRemoval = true)
	default boolean fluidRenderTypeMatches(FluidState state, RenderLayer layer) {
		return RenderLayers.getRenderLayer(state) == layer;
	}
}
