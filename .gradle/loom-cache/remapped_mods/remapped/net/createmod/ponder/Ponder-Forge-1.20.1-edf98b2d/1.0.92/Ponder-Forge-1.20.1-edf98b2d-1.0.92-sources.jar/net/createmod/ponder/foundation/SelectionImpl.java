package net.createmod.ponder.foundation;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.annotation.Nullable;

import net.createmod.catnip.outliner.Outline.OutlineParams;
import net.createmod.catnip.outliner.Outliner;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class SelectionImpl {

	public static Selection of(BlockBox bb) {
		return new Simple(bb);
	}

	private static class Compound implements Selection {
		private final Set<BlockPos> posSet;
		@Nullable
		private Vec3d center;

		public Compound(Simple initial) {
			posSet = new HashSet<>();
			add(initial);
		}

		private Compound(Set<BlockPos> template) {
			posSet = new HashSet<>(template);
		}

		@Override
		public boolean test(BlockPos t) {
			return posSet.contains(t);
		}

		@Override
		public Selection add(Selection other) {
			other.forEach(p -> posSet.add(p.immutable()));
			center = null;
			return this;
		}

		@Override
		public Selection substract(Selection other) {
			other.forEach(p -> posSet.remove(p.immutable()));
			center = null;
			return this;
		}

		@Override
		public OutlineParams makeOutline(Outliner outliner, Object slot) {
			return outliner.showCluster(slot, posSet);
		}

		@Override
		public Vec3d getCenter() {
			return center == null ? center = evalCenter() : center;
		}

		private Vec3d evalCenter() {
			Vec3d center = Vec3.ZERO;
			if (posSet.isEmpty())
				return center;
			for (BlockPos blockPos : posSet)
				center = center.add(Vec3d.atLowerCornerOf(blockPos));
			center = center.scale(1f / posSet.size());
			return center.add(new Vec3d(.5, .5, .5));
		}

		@Override
		public Selection copy() {
			return new Compound(posSet);
		}

		@Override
		public Iterator<BlockPos> iterator() {
			return posSet.iterator();
		}
	}

	private static class Simple implements Selection {
		private final BlockBox bb;
		private final Box aabb;
		private final Iterable<BlockPos> iterable;

		public Simple(BlockBox bb) {
			this.bb = bb;
			this.aabb = new Box(bb.minX(), bb.minY(), bb.minZ(), bb.maxX() + 1, bb.maxY() + 1, bb.maxZ() + 1);
			iterable = BlockPos.betweenClosed(Math.min(bb.minX(), bb.maxX()), Math.min(bb.minY(), bb.maxY()), Math.min(bb.minZ(), bb.maxZ()), Math.max(bb.minX(), bb.maxX()), Math.max(bb.minY(), bb.maxY()), Math.max(bb.minZ(), bb.maxZ()));
		}

		@Override
		public boolean test(BlockPos t) {
			return bb.isInside(t);
		}

		@Override
		public Selection add(Selection other) {
			return new Compound(this).add(other);
		}

		@Override
		public Selection substract(Selection other) {
			return new Compound(this).substract(other);
		}

		@Override
		public Vec3d getCenter() {
			return aabb.getCenter();
		}

		@Override
		public OutlineParams makeOutline(Outliner outliner, Object slot) {
			return outliner.showAABB(slot, aabb);
		}

		@Override
		public Selection copy() {
			return new Simple(new BlockBox(bb.minX(), bb.minY(), bb.minZ(), bb.maxX(), bb.maxY(), bb.maxZ()));
		}

		@Override
		public Iterator<BlockPos> iterator() {
			return iterable.iterator();
		}
	}

}
