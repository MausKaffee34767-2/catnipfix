package net.createmod.ponder.api.registration;

import java.util.List;
import java.util.Set;

import net.createmod.ponder.foundation.PonderTag;
import net.minecraft.util.Identifier;

public interface TagRegistryAccess {

	PonderTag getRegisteredTag(Identifier tagLocation);

	List<PonderTag> getListedTags();

	Set<PonderTag> getTags(Identifier item);

	Set<Identifier> getItems(Identifier tag);
	Set<Identifier> getItems(PonderTag tag);

}
