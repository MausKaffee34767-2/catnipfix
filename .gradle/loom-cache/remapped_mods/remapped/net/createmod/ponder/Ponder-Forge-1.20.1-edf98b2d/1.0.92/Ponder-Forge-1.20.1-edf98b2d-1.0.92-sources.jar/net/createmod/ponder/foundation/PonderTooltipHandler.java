package net.createmod.ponder.foundation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import com.google.common.base.Strings;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.gui.NavigatableSimiScreen;
import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.platform.CatnipClientServices;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.theme.Color;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.enums.PonderKeybinds;
import net.createmod.ponder.foundation.registration.PonderLocalization;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class PonderTooltipHandler {

	private static final Color borderA = new Color(0x5000ff, false).setImmutable();
	private static final Color borderB = new Color(0x5555ff, false).setImmutable();
	private static final Color borderC = new Color(0xffffff, false).setImmutable();

	public static boolean enable = true;

	static LerpedFloat holdKeyProgress = LerpedFloat.linear().startWithValue(0);
	static ItemStack hoveredStack = ItemStack.EMPTY;
	static ItemStack trackingStack = ItemStack.EMPTY;
	static boolean subject = false;
	static boolean deferTick = false;

	static final List<Consumer<ItemStack>> hoveredStackCallbacks = new ArrayList<>();

	public static final String HOLD_TO_PONDER = PonderLocalization.UI_PREFIX + "hold_to_ponder";
	public static final String SUBJECT = PonderLocalization.UI_PREFIX + "subject";

	public static void tick() {
		deferTick = true;
	}

	public static void deferredTick() {
		deferTick = false;
		MinecraftClient instance = MinecraftClient.getInstance();
		Screen currentScreen = instance.screen;

		if (hoveredStack.isEmpty() || trackingStack.isEmpty()) {
			trackingStack = ItemStack.EMPTY;
			holdKeyProgress.startWithValue(0);
			return;
		}

		float value = holdKeyProgress.getValue();

		if (!subject && PonderKeybinds.PONDER.isDown() && currentScreen != null) {
			if (value >= 1) {
				if (currentScreen instanceof NavigatableSimiScreen)
					((NavigatableSimiScreen) currentScreen).centerScalingOnMouse();
				ScreenOpener.transitionTo(PonderUI.of(trackingStack));
				holdKeyProgress.startWithValue(0);
				return;
			}
			holdKeyProgress.setValue(Math.min(1, value + Math.max(.25f, value) * .25f));
		} else
			holdKeyProgress.setValue(Math.max(0, value - .05f));

		hoveredStack = ItemStack.EMPTY;
	}

	public static void addToTooltip(List<Text> toolTip, ItemStack stack) {
		if (!enable)
			return;

		if (NavigatableSimiScreen.isCurrentlyRenderingPreviousScreen())
			return;

		updateHovered(stack);

		if (deferTick)
			deferredTick();

		if (trackingStack != stack)
			return;

		float renderPartialTicks = MinecraftClient.getInstance()
			.getFrameTime();
		Text component = subject ? Ponder.lang().translate(SUBJECT).component()
			.withStyle(Formatting.GREEN)
			: makeProgressBar(Math.min(1, holdKeyProgress.getValue(renderPartialTicks) * 8 / 7f));
		if (toolTip.size() < 2)
			toolTip.add(component);
		else
			toolTip.add(1, component);
	}

	protected static void updateHovered(ItemStack stack) {
		MinecraftClient instance = MinecraftClient.getInstance();
		Screen currentScreen = instance.screen;
		boolean inPonderUI = currentScreen instanceof PonderUI;

		ItemStack prevStack = trackingStack;
		hoveredStack = ItemStack.EMPTY;
		subject = false;

		if (inPonderUI) {
			PonderUI ponderUI = (PonderUI) currentScreen;
			ItemStack uiSubject = ponderUI.getSubject();
			if (!uiSubject.isEmpty() && stack.is(uiSubject.getItem()))
				subject = true;
		}

		if (stack.isEmpty())
			return;
		if (!PonderIndex.getSceneAccess().doScenesExistForId(CatnipServices.REGISTRIES.getKeyOrThrow(stack.getItem())))
			return;

		if (prevStack.isEmpty() || !prevStack.is(stack.getItem()))
			holdKeyProgress.startWithValue(0);

		hoveredStack = stack;
		trackingStack = stack;

		for (Consumer<ItemStack> hoveredStackCallback : hoveredStackCallbacks)
			hoveredStackCallback.accept(hoveredStack.copy());
	}

	public static Optional<Couple<Color>> handleTooltipColor(ItemStack stack) {
		if (trackingStack != stack)
			return Optional.empty();

		if (holdKeyProgress.getValue() == 0)
			return Optional.empty();

		float renderPartialTicks = MinecraftClient.getInstance().getFrameTime();

		Color startC;
		Color endC;
		float progress = Math.min(1, holdKeyProgress.getValue(renderPartialTicks) * 8 / 7f);

		startC = getSmoothColorForProgress(progress);
		endC = getSmoothColorForProgress(progress);

		return Optional.of(Couple.create(startC, endC));

	}

	private static Color getSmoothColorForProgress(float progress) {
		if (progress < 0.5)
			return borderA.mixWith(borderB, progress * 2);
		return borderB.mixWith(borderC, (progress - .5f) * 2);
	}

	private static Text makeProgressBar(float progress) {
		MutableText holdW = Ponder.lang()
			.translate(HOLD_TO_PONDER,
				PonderKeybinds.PONDER.message().copy().withStyle(Formatting.GRAY))
				.style(Formatting.DARK_GRAY)
				.component();

		TextRenderer fontRenderer = MinecraftClient.getInstance().font;
		float charWidth = fontRenderer.width("|");
		float tipWidth = fontRenderer.width(holdW);

		int total = (int) (tipWidth / charWidth);
		int current = (int) (progress * total);

		if (progress > 0) {
			String bars = "";
			bars += Formatting.GRAY + Strings.repeat("|", current);
			if (progress < 1)
				bars += Formatting.DARK_GRAY + Strings.repeat("|", total - current);
			return Text.literal(bars);
		}

		return holdW;
	}

	public synchronized static void registerHoveredPonderStackCallback(Consumer<ItemStack> consumer) {
		hoveredStackCallbacks.add(consumer);
	}

	public synchronized static void removeHoveredPonderStackCallback(Consumer<ItemStack> consumer) {
		hoveredStackCallbacks.remove(consumer);
	}
}
