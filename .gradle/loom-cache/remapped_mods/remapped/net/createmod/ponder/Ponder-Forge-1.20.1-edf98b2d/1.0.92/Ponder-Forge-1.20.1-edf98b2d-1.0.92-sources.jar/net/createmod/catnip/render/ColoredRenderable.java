package net.createmod.catnip.render;

import net.createmod.catnip.theme.Color;
import net.minecraft.client.gui.DrawContext;

public interface ColoredRenderable {

	void render(DrawContext graphics, int x, int y, Color c);

}
