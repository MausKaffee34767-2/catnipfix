package net.createmod.catnip.platform;

import net.createmod.catnip.placement.IPlacementHelper;
import net.createmod.catnip.platform.services.ModHooksHelper;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.level.BlockEvent;

public class ForgeHooksHelper implements ModHooksHelper {

	@Override
	public boolean playerPlaceSingleBlock(PlayerEntity player, World level, BlockPos pos, BlockState newState) {
		BlockSnapshot snapshot = BlockSnapshot.create(level.dimension(), level, pos);
		level.setBlockAndUpdate(pos, newState);

		BlockEvent.EntityPlaceEvent event = new BlockEvent.EntityPlaceEvent(snapshot, IPlacementHelper.ID, player);
		if (MinecraftForge.EVENT_BUS.post(event)) {
			snapshot.restore(true, false);
			return true;
		}

		return false;
	}

	@Override
	public ItemStack getCloneItemFromBlockstate(BlockState state, HitResult target, BlockView level, BlockPos pos, PlayerEntity player) {
		return state.getCloneItemStack(target, level, pos, player);
	}

	@Override
	public boolean isPlayerFake(ServerPlayerEntity player) {
		return player instanceof FakePlayer;
	}
}
