package net.createmod.catnip.impl.client.render.model;

import java.util.Iterator;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;
import dev.engine_room.flywheel.lib.model.baked.VirtualBlockGetter;
import net.createmod.catnip.client.render.model.ShadeSeparatedBufferSource;
import net.createmod.catnip.client.render.model.ShadeSeparatedResultConsumer;
import net.createmod.catnip.impl.client.render.TransformingVertexConsumer;
import net.createmod.ponder.render.VirtualRenderHelper;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.data.ModelData;

// Modified from https://github.com/Engine-Room/Flywheel/blob/2f67f54c8898d91a48126c3c753eefa6cd224f84/forge/src/lib/java/dev/engine_room/flywheel/lib/model/baked/BakedModelBufferer.java
public final class BakedModelBuffererImpl {
	private static final ThreadLocal<ThreadLocalObjects> THREAD_LOCAL_OBJECTS = ThreadLocal.withInitial(ThreadLocalObjects::new);

	private BakedModelBuffererImpl() {
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, @Nullable ModelData modelData, ShadeSeparatedBufferSource bufferSource) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();
		if (poseStack == null) {
			poseStack = objects.identityPoseStack;
		}
		if (modelData == null) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			modelData = blockEntity != null ? blockEntity.getModelData() : (level instanceof VirtualBlockGetter ? VirtualRenderHelper.VIRTUAL_DATA : ModelData.EMPTY);
		}
		Random random = objects.random;
		UniversalMeshEmitter universalEmitter = objects.universalEmitter;

		long seed = state.getSeed(pos);
		modelData = model.getModelData(level, pos, state, modelData);
		random.setSeed(seed);
		ChunkRenderTypeSet renderTypes = model.getRenderTypes(state, random, modelData);

		BlockModelRenderer blockRenderer = MinecraftClient.getInstance()
			.getBlockRenderer()
			.getModelRenderer();

		for (RenderLayer renderType : renderTypes) {
			universalEmitter.prepare(bufferSource, renderType);
			poseStack.pushPose();
			blockRenderer.tesselateBlock(level, model, state, pos, poseStack, universalEmitter, false, random, seed, OverlayTexture.NO_OVERLAY, modelData, renderType);
			poseStack.popPose();
		}

		universalEmitter.clear();
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, @Nullable ModelData modelData, ShadeSeparatedResultConsumer resultConsumer) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();
		DefaultShadeSeparatedBufferSource bufferSource = objects.defaultBufferSource;
		bufferSource.prepare(resultConsumer);
		bufferModel(model, pos, level, state, poseStack, modelData, bufferSource);
		bufferSource.end();
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, @Nullable Function<BlockPos, ModelData> modelDataLookup, boolean renderFluids, ShadeSeparatedBufferSource bufferSource) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();
		if (poseStack == null) {
			poseStack = objects.identityPoseStack;
		}
		if (modelDataLookup == null) {
			modelDataLookup = pos -> {
				BlockEntity blockEntity = level.getBlockEntity(pos);
				return blockEntity != null ? blockEntity.getModelData() : (level instanceof VirtualBlockGetter ? VirtualRenderHelper.VIRTUAL_DATA : ModelData.EMPTY);
			};
		}
		Random random = objects.random;
		UniversalMeshEmitter universalEmitter = objects.universalEmitter;
		TransformingVertexConsumer transformingWrapper = objects.transformingWrapper;

		BlockRenderManager renderDispatcher = MinecraftClient.getInstance()
			.getBlockRenderer();

		BlockModelRenderer blockRenderer = renderDispatcher.getModelRenderer();
		BlockModelRenderer.enableCaching();

		while (posIterator.hasNext()) {
			BlockPos pos = posIterator.next();
			BlockState state = level.getBlockState(pos);

			if (renderFluids) {
				FluidState fluidState = state.getFluidState();

				if (!fluidState.isEmpty()) {
					RenderLayer renderType = RenderLayers.getRenderLayer(fluidState);

					transformingWrapper.prepare(bufferSource.getBuffer(renderType, true), poseStack);

					poseStack.pushPose();
					poseStack.translate(pos.getX() - (pos.getX() & 0xF), pos.getY() - (pos.getY() & 0xF), pos.getZ() - (pos.getZ() & 0xF));
					renderDispatcher.renderLiquid(pos, level, transformingWrapper, state, fluidState);
					poseStack.popPose();
				}
			}

			if (state.getRenderShape() == BlockRenderType.MODEL) {
				long seed = state.getSeed(pos);
				BakedModel model = renderDispatcher.getBlockModel(state);
				ModelData modelData = modelDataLookup.apply(pos);
				modelData = model.getModelData(level, pos, state, modelData);
				random.setSeed(seed);
				ChunkRenderTypeSet renderTypes = model.getRenderTypes(state, random, modelData);

				for (RenderLayer renderType : renderTypes) {
					universalEmitter.prepare(bufferSource, renderType);
					poseStack.pushPose();
					poseStack.translate(pos.getX(), pos.getY(), pos.getZ());
					blockRenderer.tesselateBlock(level, model, state, pos, poseStack, universalEmitter, true, random, seed, OverlayTexture.NO_OVERLAY, modelData, renderType);
					poseStack.popPose();
				}
			}
		}

		BlockModelRenderer.clearCache();
		transformingWrapper.clear();
		universalEmitter.clear();
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, @Nullable Function<BlockPos, ModelData> modelDataLookup, boolean renderFluids, ShadeSeparatedResultConsumer resultConsumer) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();
		DefaultShadeSeparatedBufferSource bufferSource = objects.defaultBufferSource;
		bufferSource.prepare(resultConsumer);
		bufferBlocks(posIterator, level, poseStack, modelDataLookup, renderFluids, bufferSource);
		bufferSource.end();
	}

	private static class ThreadLocalObjects {
		public final MatrixStack identityPoseStack = new MatrixStack();
		public final Random random = Random.createNewThreadLocalInstance();

		public final DefaultShadeSeparatedBufferSource defaultBufferSource = new DefaultShadeSeparatedBufferSource();
		public final UniversalMeshEmitter universalEmitter = new UniversalMeshEmitter();
		public final TransformingVertexConsumer transformingWrapper = new TransformingVertexConsumer();
	}
}
