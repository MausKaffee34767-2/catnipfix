package net.createmod.catnip.levelWrappers;

import net.minecraft.util.Identifier;
import net.minecraft.world.WorldAccess;

public class WorldHelper {
	public static Identifier getDimensionID(WorldAccess world) {
		return world.registryAccess()
			.registryOrThrow(Registries.DIMENSION_TYPE)
			.getKey(world.dimensionType());
	}
}
