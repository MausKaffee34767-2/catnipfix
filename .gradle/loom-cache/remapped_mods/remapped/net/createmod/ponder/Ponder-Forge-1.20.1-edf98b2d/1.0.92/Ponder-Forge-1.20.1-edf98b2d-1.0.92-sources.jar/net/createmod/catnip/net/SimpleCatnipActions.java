package net.createmod.catnip.net;

import net.createmod.catnip.config.ui.ConfigHelper;
import net.createmod.catnip.config.ui.ConfigModListScreen;
import net.createmod.catnip.config.ui.SubMenuConfigScreen;
import net.createmod.catnip.gui.ScreenOpener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class SimpleCatnipActions {

	public static void configScreen(String value) {
		if (value.equals("")) {
			ScreenOpener.open(new ConfigModListScreen(null));
			return;
		}

		ClientPlayerEntity player = MinecraftClient.getInstance().player;

		if (player == null)
			return;

		ConfigHelper.ConfigPath configPath;
		try {
			configPath = ConfigHelper.ConfigPath.parse(value);
		} catch (IllegalArgumentException e) {
			player.displayClientMessage(Text.literal(e.getMessage()), false);
			return;
		}

		try {
			ScreenOpener.open(SubMenuConfigScreen.find(configPath));
		} catch (Exception e) {
			player.displayClientMessage(Text.literal("[Catnip]: ").withStyle(Formatting.YELLOW).append(Text.translatable("catnip.util.unable_to_find_config.message").withStyle(Formatting.WHITE)), false);
		}
	}

}
