package net.createmod.ponder.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.server.command.ServerCommandSource;

public class PonderCommands {

	public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
		CommandNode<ServerCommandSource> ponderRoot = PonderCommand.register().build();

		dispatcher.getRoot().addChild(ponderRoot);
	}

}
