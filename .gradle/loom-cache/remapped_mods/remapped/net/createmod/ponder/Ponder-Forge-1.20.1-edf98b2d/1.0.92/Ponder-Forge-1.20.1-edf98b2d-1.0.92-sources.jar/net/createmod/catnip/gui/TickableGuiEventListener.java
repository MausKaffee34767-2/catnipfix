package net.createmod.catnip.gui;

import net.minecraft.client.gui.Element;

public interface TickableGuiEventListener extends Element {
	void tick();
}
