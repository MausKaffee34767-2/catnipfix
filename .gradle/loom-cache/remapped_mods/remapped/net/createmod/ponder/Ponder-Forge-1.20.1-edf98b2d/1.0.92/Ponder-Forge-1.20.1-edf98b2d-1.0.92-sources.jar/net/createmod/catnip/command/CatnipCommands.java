package net.createmod.catnip.command;

import java.util.Collections;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;

public class CatnipCommands {

	public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {

		LiteralCommandNode<ServerCommandSource> util = buildUtilityCommands();

		LiteralCommandNode<ServerCommandSource> catnipRoot = CommandManager.literal("catnip")
				.requires(cs -> cs.hasPermission(0))
				.then(ConfigCommand.register())
				.then(util)
				.build();

		catnipRoot.addChild(buildRedirect("u", util));

		dispatcher.getRoot().addChild(catnipRoot);

		//add all of Catnip's commands to /c if it already exists, otherwise create the shortcut
		createOrAddToShortcut(dispatcher, "c", catnipRoot);
	}

	private static LiteralCommandNode<ServerCommandSource> buildUtilityCommands() {

		return CommandManager.literal("util")
				.then(FlySpeedCommand.register())
				.build();

	}

	/**
	 * *****
	 * <a href="https://github.com/VelocityPowered/Velocity/blob/8abc9c80a69158ebae0121fda78b55c865c0abad/proxy/src/main/java/com/velocitypowered/proxy/util/BrigadierUtils.java#L38">Source</a>
	 * *****
	 * <p>
	 * Returns a literal node that redirects its execution to
	 * the given destination node.
	 *
	 * @param alias       the command alias
	 * @param destination the destination node
	 *
	 * @return the built node
	 */
	public static LiteralCommandNode<ServerCommandSource> buildRedirect(final String alias, final LiteralCommandNode<ServerCommandSource> destination) {
		// Redirects only work for nodes with children, but break the top argument-less command.
		// Manually adding the root command after setting the redirect doesn't fix it.
		// See https://github.com/Mojang/brigadier/issues/46). Manually clone the node instead.
		LiteralArgumentBuilder<ServerCommandSource> builder = LiteralArgumentBuilder
				.<ServerCommandSource>literal(alias)
				.requires(destination.getRequirement())
				.forward(destination.getRedirect(), destination.getRedirectModifier(), destination.isFork())
				.executes(destination.getCommand());
		for (CommandNode<ServerCommandSource> child : destination.getChildren()) {
			builder.then(child);
		}
		return builder.build();
	}

	public static void createOrAddToShortcut(CommandDispatcher<ServerCommandSource> dispatcher, String shortcut, LiteralCommandNode<ServerCommandSource> createRoot) {
		CommandNode<ServerCommandSource> node = dispatcher.findNode(Collections.singleton(shortcut));
		if (node != null) {
			for (CommandNode<ServerCommandSource> child : createRoot.getChildren()) {
				node.addChild(child);
			}
			return;
		}

		dispatcher.getRoot().addChild(CatnipCommands.buildRedirect(shortcut, createRoot));
	}
}
