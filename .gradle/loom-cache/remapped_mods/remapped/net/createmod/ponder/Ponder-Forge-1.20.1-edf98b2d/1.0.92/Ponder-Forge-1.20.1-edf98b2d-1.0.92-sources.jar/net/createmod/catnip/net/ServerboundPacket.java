package net.createmod.catnip.net;

import javax.annotation.Nullable;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

public interface ServerboundPacket extends BasePacket {

	void handle(@Nullable MinecraftServer server, @Nullable ServerPlayerEntity player);

}
