package net.createmod.catnip.gui;

import net.minecraft.client.render.DiffuseLighting;

public interface ILightingSettings {

	void applyLighting();

	static final ILightingSettings DEFAULT_3D = DiffuseLighting::setupFor3DItems;
	static final ILightingSettings DEFAULT_FLAT = DiffuseLighting::setupForFlatItems;

}
