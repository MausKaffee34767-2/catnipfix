package net.createmod.catnip.platform.services;

import net.createmod.catnip.net.BasePacket;
import net.createmod.catnip.net.ClientboundSimpleActionPacket;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface NetworkHelper {

	void sendToPlayer(PlayerEntity player, BasePacket packet);

	void sendToNear(World level, BlockPos pos, int range, BasePacket packet);

	void sendToEntity(Entity entity, BasePacket packet);

	void sendToServer(BasePacket packet);

	default void simpleActionToClient(PlayerEntity player, String action, String value) {
		sendToPlayer(player, new ClientboundSimpleActionPacket(action, value));
	}

}
