package net.createmod.catnip.render;

import java.util.Objects;

import javax.annotation.Nullable;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.Identifier;

public class SpriteShiftEntry {
	@Nullable protected StitchedSprite original;
	@Nullable protected StitchedSprite target;

	public void set(Identifier originalLocation, Identifier targetLocation) {
		original = new StitchedSprite(originalLocation);
		target = new StitchedSprite(targetLocation);
	}

	public Identifier getOriginalResourceLocation() {
		Objects.requireNonNull(original);
		return original.getLocation();
	}

	public Identifier getTargetResourceLocation() {
		Objects.requireNonNull(target);
		return target.getLocation();
	}

	public Sprite getOriginal() {
		Objects.requireNonNull(original);
		return original.get();
	}

	public Sprite getTarget() {
		Objects.requireNonNull(target);
		return target.get();
	}

	public float getTargetU(float localU) {
		return getTarget().getU(getUnInterpolatedU(getOriginal(), localU));
	}

	public float getTargetV(float localV) {
		return getTarget().getV(getUnInterpolatedV(getOriginal(), localV));
	}

	public static float getUnInterpolatedU(Sprite sprite, float u) {
		float f = sprite.getU1() - sprite.getU0();
		return (u - sprite.getU0()) / f * 16.0F;
	}

	public static float getUnInterpolatedV(Sprite sprite, float v) {
		float f = sprite.getV1() - sprite.getV0();
		return (v - sprite.getV0()) / f * 16.0F;
	}
}
