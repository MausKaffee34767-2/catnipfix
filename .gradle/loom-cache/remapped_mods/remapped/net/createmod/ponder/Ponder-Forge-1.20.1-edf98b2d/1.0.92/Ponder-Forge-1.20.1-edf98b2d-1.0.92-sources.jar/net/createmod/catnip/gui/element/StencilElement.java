package net.createmod.catnip.gui.element;

import org.lwjgl.opengl.GL11;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;

public interface StencilElement extends RenderElement {

	@Override
	default void render(DrawContext graphics) {
		graphics.pose().pushPose();
		transform(graphics);
		prepareStencil(graphics);
		renderStencil(graphics);
		prepareElement(graphics);
		renderElement(graphics);
		cleanUp(graphics);
		graphics.pose().popPose();
	}

	void renderStencil(DrawContext graphics);

	void renderElement(DrawContext graphics);

	default void transform(DrawContext graphics) {
		graphics.pose().translate(getX(), getY(), getZ());
	}

	default void prepareStencil(DrawContext graphics) {
		graphics.flush();
		GL11.glDisable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilMask(~0);
		RenderSystem.clear(GL11.GL_STENCIL_BUFFER_BIT, Minecraft.ON_OSX);
		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_REPLACE, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilMask(0xFF);
		RenderSystem.stencilFunc(GL11.GL_NEVER, 1, 0xFF);
	}

	default void prepareElement(DrawContext graphics) {
		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilFunc(GL11.GL_EQUAL, 1, 0xFF);
	}

	default void cleanUp(DrawContext graphics) {
		GL11.glDisable(GL11.GL_STENCIL_TEST);
		graphics.flush();

	}
}
