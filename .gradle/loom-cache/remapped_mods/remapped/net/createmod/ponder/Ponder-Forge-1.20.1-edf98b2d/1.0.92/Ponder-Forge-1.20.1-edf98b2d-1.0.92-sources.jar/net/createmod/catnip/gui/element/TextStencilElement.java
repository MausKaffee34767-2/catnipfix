package net.createmod.catnip.gui.element;

import net.createmod.catnip.theme.Color;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

public class TextStencilElement extends DelegatedStencilElement {

	protected TextRenderer font;
	protected MutableText component = Text.empty();
	protected boolean centerVertically = false;
	protected boolean centerHorizontally = false;

	public TextStencilElement(TextRenderer font) {
		super();
		this.font = font;
		height = 10;
	}

	public TextStencilElement(TextRenderer font, String text) {
		this(font);
		component = Text.literal(text);
	}

	public TextStencilElement(TextRenderer font, MutableText component) {
		this(font);
		this.component = component;
	}

	public TextStencilElement withText(String text) {
		component = Text.literal(text);
		return this;
	}

	public TextStencilElement withText(MutableText component) {
		this.component = component;
		return this;
	}

	public TextStencilElement centered(boolean vertical, boolean horizontal) {
		this.centerVertically = vertical;
		this.centerHorizontally = horizontal;
		return this;
	}

	@Override
	public void renderStencil(DrawContext graphics) {

		float x = 0, y = 0;
		if (centerHorizontally)
			x = width / 2f - font.width(component) / 2f;

		if (centerVertically)
			y = height / 2f - (font.lineHeight - 1) / 2f;

		graphics.drawString(font, component, Math.round(x), Math.round(y), Color.BLACK.getRGB(), false);
		graphics.flush();
	}

	@Override
	public void renderElement(DrawContext graphics) {
		float x = 0, y = 0;
		if (centerHorizontally)
			x = width / 2f - font.width(component) / 2f;

		if (centerVertically)
			y = height / 2f - (font.lineHeight - 1) / 2f;

		MatrixStack poseStack = graphics.pose();
		poseStack.pushPose();
		poseStack.translate(x, y, 0);
		element.render(graphics, font.width(component), font.lineHeight + 2, alpha);
		poseStack.popPose();
	}

	public MutableText getComponent() {
		return component;
	}
}
