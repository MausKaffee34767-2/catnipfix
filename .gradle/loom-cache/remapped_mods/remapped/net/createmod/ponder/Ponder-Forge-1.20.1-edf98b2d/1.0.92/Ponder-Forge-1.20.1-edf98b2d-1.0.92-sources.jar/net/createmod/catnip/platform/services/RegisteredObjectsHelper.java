package net.createmod.catnip.platform.services;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.EntityType;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.particle.ParticleType;
import net.minecraft.potion.Potion;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;

public interface RegisteredObjectsHelper<R> {

	<V> Identifier getKeyOrThrow(R registry, V value);

	Identifier getKeyOrThrow(Block value);

	Identifier getKeyOrThrow(Item value);

	Identifier getKeyOrThrow(Fluid value);

	Identifier getKeyOrThrow(EntityType<?> value);

	Identifier getKeyOrThrow(BlockEntityType<?> value);

	Identifier getKeyOrThrow(Potion value);

	Identifier getKeyOrThrow(ParticleType<?> value);

	Identifier getKeyOrThrow(RecipeSerializer<?> value);

	@Nullable
	Item getItem(Identifier location);

	@Nullable
	Block getBlock(Identifier location);

	@Nullable
	default ItemConvertible getItemOrBlock(Identifier location) {
		Item item = getItem(location);
		if (item != null)
			return item;

		return getBlock(location);
	}

	default Identifier getKeyOrThrow(ItemConvertible itemLike) {
		if (itemLike instanceof Item item) {
			return getKeyOrThrow(item);
		} else if (itemLike instanceof Block block) {
			return getKeyOrThrow(block);
		}

		throw new IllegalArgumentException("Could not get key for itemLike " + itemLike + "!");
	}

}
