package net.createmod.ponder.foundation.element;

import java.util.function.Supplier;

import javax.annotation.Nullable;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.ponder.api.element.ParrotElement;
import net.createmod.ponder.api.element.ParrotPose;
import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.passive.ParrotEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ParrotElementImpl extends AnimatedSceneElementBase implements ParrotElement {

	protected Vec3d location;
	@Nullable protected ParrotEntity entity;
	protected ParrotPose pose;
	protected Supplier<? extends ParrotPose> initialPose;

	public static ParrotElement create(Vec3d location, Supplier<? extends ParrotPose> pose) {
		return new ParrotElementImpl(location, pose);
	}

	protected ParrotElementImpl(Vec3d location, Supplier<? extends ParrotPose> pose) {
		this.location = location;
		initialPose = pose;
		this.pose = initialPose.get();
	}

	@Override
	public void reset(PonderScene scene) {
		super.reset(scene);
		setPose(initialPose.get());
		entity.setPosRaw(0, 0, 0);
		entity.xo = 0;
		entity.yo = 0;
		entity.zo = 0;
		entity.xOld = 0;
		entity.yOld = 0;
		entity.zOld = 0;
		entity.setXRot(entity.xRotO = 0);
		entity.setYRot(entity.yRotO = 180);
	}

	@Override
	public void tick(PonderScene scene) {
		super.tick(scene);
		if (entity == null) {
			entity = pose.create(scene.getWorld());
			entity.setYRot(entity.yRotO = 180);
		}

		entity.tickCount++;
		entity.yHeadRotO = entity.yHeadRot;
		entity.oFlapSpeed = entity.flapSpeed;
		entity.oFlap = entity.flap;
		entity.setOnGround(true);

		entity.xo = entity.getX();
		entity.yo = entity.getY();
		entity.zo = entity.getZ();
		entity.yRotO = entity.getYRot();
		entity.xRotO = entity.getXRot();

		pose.tick(scene, entity, location);

		entity.xOld = entity.getX();
		entity.yOld = entity.getY();
		entity.zOld = entity.getZ();
	}

	@Override
	public void setPositionOffset(Vec3d position, boolean immediate) {
		if (entity == null)
			return;
		entity.setPos(position.x, position.y, position.z);
		if (!immediate)
			return;
		entity.xo = position.x;
		entity.yo = position.y;
		entity.zo = position.z;
	}

	@Override
	public void setRotation(Vec3d eulers, boolean immediate) {
		if (entity == null)
			return;
		entity.setXRot((float) eulers.x);
		entity.setYRot((float) eulers.y);
		if (!immediate)
			return;
		entity.xRotO = entity.getXRot();
		entity.yRotO = entity.getYRot();
	}

	@Override
	public Vec3d getPositionOffset() {
		return entity != null ? entity.position() : Vec3.ZERO;
	}

	@Override
	public Vec3d getRotation() {
		return entity != null ? new Vec3d(entity.getXRot(), entity.getYRot(), 0) : Vec3.ZERO;
	}

	@Override
	protected void renderLast(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float fade, float pt) {
		MatrixStack poseStack = graphics.pose();
		EntityRenderDispatcher entityrenderermanager = MinecraftClient.getInstance()
			.getEntityRenderDispatcher();

		if (entity == null) {
			entity = pose.create(world);
			entity.setYRot(entity.yRotO = 180);
		}

		poseStack.pushPose();
		poseStack.translate(location.x, location.y, location.z);
		poseStack.translate(MathHelper.lerp(pt, entity.xo, entity.getX()), MathHelper.lerp(pt, entity.yo, entity.getY()),
			MathHelper.lerp(pt, entity.zo, entity.getZ()));

		float angle = AngleHelper.angleLerp(pt, entity.yRotO, entity.getYRot());
		poseStack.mulPose(Axis.YP.rotationDegrees(angle));

		entityrenderermanager.render(entity, 0, 0, 0, 0, pt, poseStack, buffer, lightCoordsFromFade(fade));
		poseStack.popPose();
	}

	@Override
	public void setPose(ParrotPose pose) {
		this.pose = pose;
	}

}
