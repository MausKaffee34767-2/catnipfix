package net.createmod.ponder.foundation;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.gui.element.ScreenElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class PonderChapter implements ScreenElement {

	private final Identifier id;
	private final Identifier icon;

	private PonderChapter(Identifier id) {
		this.id = id;
		icon = new Identifier(id.getNamespace(), "textures/ponder/chapter/" + id.getPath() + ".png");
	}

	public Identifier getId() {
		return id;
	}

	public String getTitle() {
		return "";
	}

	@Override
	public void render(DrawContext graphics, int x, int y) {
		MatrixStack ms = graphics.pose();
		ms.pushPose();
		RenderSystem.setShaderTexture(0, icon);
		ms.scale(0.25f, 0.25f, 1);
		//x and y offset, blit z offset, tex x and y, tex width and height, entire tex sheet width and height
		graphics.blit(icon, x, y, 0, 0, 0, 64, 64, 64, 64);
		ms.popPose();
	}

	@Deprecated
	public static PonderChapter of(Identifier id) {
		/*PonderChapter chapter = PonderRegistry.CHAPTERS.getChapter(id);
		if (chapter == null) {
			 chapter = PonderRegistry.CHAPTERS.addChapter(new PonderChapter(id));
		}

		return chapter;*/
		return null;
	}
}
