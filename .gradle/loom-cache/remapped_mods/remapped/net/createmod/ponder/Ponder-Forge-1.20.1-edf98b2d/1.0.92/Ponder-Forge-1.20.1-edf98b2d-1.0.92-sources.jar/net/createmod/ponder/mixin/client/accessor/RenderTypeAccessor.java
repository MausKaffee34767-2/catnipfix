package net.createmod.ponder.mixin.client.accessor;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderLayer.class)
public interface RenderTypeAccessor {
	@Invoker("create")
	static RenderLayer.MultiPhase catnip$create(String string, VertexFormat vertexFormat, VertexFormat.DrawMode mode, int i, boolean bl, boolean bl2, RenderLayer.MultiPhaseParameters compositeState) {
		throw new AssertionError("Mixin application failed!");
	}
}

