package net.createmod.catnip.client.render.model;

import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.RenderLayer;

public interface ShadeSeparatedResultConsumer {
	void accept(RenderLayer renderType, boolean shaded, BufferBuilder.BuiltBuffer data);
}
