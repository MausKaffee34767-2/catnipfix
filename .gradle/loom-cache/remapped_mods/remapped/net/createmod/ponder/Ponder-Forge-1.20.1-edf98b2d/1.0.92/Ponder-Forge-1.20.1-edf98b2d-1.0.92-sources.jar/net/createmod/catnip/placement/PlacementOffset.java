package net.createmod.catnip.placement;

import java.util.function.Function;

import javax.annotation.Nullable;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class PlacementOffset {

	private final boolean success;
	private Vec3i pos;
	private Function<BlockState, BlockState> stateTransform;
	@Nullable
	private BlockState ghostState;

	private PlacementOffset(boolean success) {
		this.success = success;
		this.pos = BlockPos.ZERO;
		this.stateTransform = Function.identity();
		this.ghostState = null;
	}

	public static PlacementOffset fail() {
		return new PlacementOffset(false);
	}

	public static PlacementOffset success() {
		return new PlacementOffset(true);
	}

	public static PlacementOffset success(Vec3i pos) {
		return success().at(pos);
	}

	public static PlacementOffset success(Vec3i pos, Function<BlockState, BlockState> transform) {
		return success().at(pos).withTransform(transform);
	}

	public PlacementOffset at(Vec3i pos) {
		this.pos = pos;
		return this;
	}

	public PlacementOffset withTransform(Function<BlockState, BlockState> stateTransform) {
		this.stateTransform = stateTransform;
		return this;
	}

	public PlacementOffset withGhostState(BlockState ghostState) {
		this.ghostState = ghostState;
		return this;
	}

	public boolean isSuccessful() {
		return success;
	}

	public Vec3i getPos() {
		return pos;
	}

	public BlockPos getBlockPos() {
		if (pos instanceof BlockPos)
			return (BlockPos) pos;

		return new BlockPos(pos);
	}

	public Function<BlockState, BlockState> getTransform() {
		return stateTransform;
	}

	public boolean hasGhostState() {
		return ghostState != null;
	}

	@Nullable
	public BlockState getGhostState() {
		return ghostState;
	}

	public boolean isReplaceable(World world) {
		if (!success)
			return false;

		return world.getBlockState(new BlockPos(pos)).canBeReplaced();
	}

	public ActionResult placeInWorld(World world, BlockItem blockItem, PlayerEntity player, Hand hand, BlockHitResult ray) {

		if (!isReplaceable(world))
			return ActionResult.PASS;

		if (world.isClientSide)
			return ActionResult.SUCCESS;

		ItemUsageContext context = new ItemUsageContext(player, hand, ray);
		BlockPos newPos = new BlockPos(pos);
		ItemStack stackBefore = player.getItemInHand(hand)
			.copy();

		if (!world.mayInteract(player, newPos))
			return ActionResult.PASS;

		BlockState state = stateTransform.apply(blockItem.getBlock().defaultBlockState());
		if (state.hasProperty(BlockStateProperties.WATERLOGGED)) {
			FluidState fluidState = world.getFluidState(newPos);
			state = state.setValue(BlockStateProperties.WATERLOGGED, fluidState.getType() == Fluids.WATER);
		}

		if (CatnipServices.HOOKS.playerPlaceSingleBlock(player, world, newPos, state)) {
			return ActionResult.FAIL;
		}

		BlockState newState = world.getBlockState(newPos);
		BlockSoundGroup soundtype = newState.getSoundType();
		world.playSound(null, newPos, soundtype.getPlaceSound(), SoundCategory.BLOCKS, (soundtype.getVolume() + 1.0F) / 2.0F, soundtype.getPitch() * 0.8F);
		world.gameEvent(GameEvent.BLOCK_PLACE, newPos, GameEvent.Emitter.of(player, newState));

		player.awardStat(Stats.ITEM_USED.get(blockItem));
		newState.getBlock()
			.setPlacedBy(world, newPos, newState, player, stackBefore);

		if (player instanceof ServerPlayerEntity)
			CriteriaTriggers.PLACED_BLOCK.trigger((ServerPlayerEntity) player, newPos, context.getItemInHand());

		if (!player.isCreative())
			context.getItemInHand().shrink(1);

		return ActionResult.SUCCESS;
	}
}
