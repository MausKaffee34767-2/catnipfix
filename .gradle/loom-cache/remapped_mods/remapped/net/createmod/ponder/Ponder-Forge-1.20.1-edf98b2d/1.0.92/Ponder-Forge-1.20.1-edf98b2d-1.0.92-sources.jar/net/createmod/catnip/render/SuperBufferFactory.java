package net.createmod.catnip.render;

import javax.annotation.Nullable;
import dev.engine_room.flywheel.lib.model.baked.EmptyVirtualBlockGetter;
import net.createmod.catnip.client.render.model.BakedModelBufferer;
import net.createmod.catnip.client.render.model.ShadeSeparatedResultConsumer;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder.BuiltBuffer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;

public class SuperBufferFactory {

	private static final ThreadLocal<ThreadLocalObjects> THREAD_LOCAL_OBJECTS = ThreadLocal.withInitial(ThreadLocalObjects::new);

	private static SuperBufferFactory instance = new SuperBufferFactory();

	public static SuperBufferFactory getInstance() {
		return instance;
	}

	static void setInstance(SuperBufferFactory factory) {
		instance = factory;
	}

	public SuperByteBuffer create(BuiltBuffer data) {
		return new ShadeSeparatingSuperByteBuffer(new MutableTemplateMesh(data).toImmutable());
	}

	public SuperByteBuffer createForBlock(BlockState renderedState) {
		return createForBlock(MinecraftClient.getInstance().getBlockRenderer().getBlockModel(renderedState), renderedState);
	}

	public SuperByteBuffer createForBlock(BakedModel model, BlockState referenceState) {
		return createForBlock(model, referenceState, new MatrixStack());
	}

	public SuperByteBuffer createForBlock(BakedModel model, BlockState state, @Nullable MatrixStack poseStack) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();
		SbbBuilder sbbBuilder = objects.sbbBuilder;
		sbbBuilder.prepare();
		BakedModelBufferer.bufferModel(model, BlockPos.ZERO, EmptyVirtualBlockGetter.FULL_DARK, state, poseStack, sbbBuilder);
		return sbbBuilder.build();
	}

	private static class SbbBuilder extends SuperByteBufferBuilder implements ShadeSeparatedResultConsumer {
		@Override
		public void accept(RenderLayer renderType, boolean shaded, BuiltBuffer data) {
			add(data, shaded);
		}
	}

	private static class ThreadLocalObjects {
		public final SbbBuilder sbbBuilder = new SbbBuilder();
	}
}
