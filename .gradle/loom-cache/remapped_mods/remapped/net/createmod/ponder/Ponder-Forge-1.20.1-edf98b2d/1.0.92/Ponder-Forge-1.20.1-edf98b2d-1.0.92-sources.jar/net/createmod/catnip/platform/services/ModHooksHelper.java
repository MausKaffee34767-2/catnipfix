package net.createmod.catnip.platform.services;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public interface ModHooksHelper {

	/**
	 * Attempts to place a single Block as a Player, and should fire according events
	 *
	 * @return True if the event got canceled or the Block was not be placed, False otherwise
	 */
	boolean playerPlaceSingleBlock(PlayerEntity player, World level, BlockPos pos, BlockState newState);

	default ItemStack getCloneItemFromBlockstate(BlockState state, HitResult target, BlockView level, BlockPos pos, PlayerEntity player) {
		return state.getBlock().getCloneItemStack(level, pos, state);
	}

	boolean isPlayerFake(ServerPlayerEntity player);

}
