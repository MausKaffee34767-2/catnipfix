package net.createmod.catnip.levelWrappers;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import net.createmod.ponder.mixin.accessor.EntityAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.map.MapState;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.chunk.light.LightingProvider;
import net.minecraft.world.entity.EntityLookup;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.tick.QueryableTickScheduler;

public class WrappedLevel extends World {

	protected World level;
	protected ChunkManager chunkSource;

	protected EntityLookup<Entity> entityGetter = new DummyLevelEntityGetter<>();

	public WrappedLevel(World level) {
		super((MutableWorldProperties) level.getLevelData(), level.dimension(), level.registryAccess(), level.dimensionTypeRegistration(),
			  level::getProfiler, level.isClientSide, level.isDebug(), 0, 0);
		this.level = level;
	}

	public void setChunkSource(ChunkManager source) {
		this.chunkSource = source;
	}

	public World getLevel() {
		return level;
	}

	@Override
	public LightingProvider getLightEngine() {
		return level.getLightEngine();
	}

	@Override
	public BlockState getBlockState(@Nullable BlockPos pos) {
		return level.getBlockState(pos);
	}

	@Override
	public boolean isStateAtPosition(BlockPos p_217375_1_, Predicate<BlockState> p_217375_2_) {
		return level.isStateAtPosition(p_217375_1_, p_217375_2_);
	}

	@Override
	@Nullable
	public BlockEntity getBlockEntity(BlockPos pos) {
		return level.getBlockEntity(pos);
	}

	@Override
	public boolean setBlock(BlockPos pos, BlockState newState, int flags) {
		return level.setBlock(pos, newState, flags);
	}

	@Override
	public int getMaxLocalRawBrightness(BlockPos pos) {
		return 15;
	}

	@Override
	public void sendBlockUpdated(BlockPos pos, BlockState oldState, BlockState newState, int flags) {
		level.sendBlockUpdated(pos, oldState, newState, flags);
	}

	@Override
	public QueryableTickScheduler<Block> getBlockTicks() {
		return level.getBlockTicks();
	}

	@Override
	public QueryableTickScheduler<Fluid> getFluidTicks() {
		return level.getFluidTicks();
	}

	@Override
	public ChunkManager getChunkSource() {
		return chunkSource != null ? chunkSource : level.getChunkSource();
	}

	@Override
	public void levelEvent(@Nullable PlayerEntity player, int type, BlockPos pos, int data) {}

	@Override
	public List<? extends PlayerEntity> players() {
		return Collections.emptyList();
	}

	@Override
	public void playSeededSound(PlayerEntity pPlayer, double pX, double pY, double pZ, RegistryEntry<SoundEvent> pSound,
								SoundCategory pSource, float pVolume, float pPitch, long pSeed) {}

	@Override
	public void playSeededSound(PlayerEntity pPlayer, Entity pEntity, RegistryEntry<SoundEvent> pSound, SoundCategory pCategory,
								float pVolume, float pPitch, long pSeed) {}

	@Override
	public void playSound(@Nullable PlayerEntity player, double x, double y, double z, SoundEvent soundIn,
		SoundCategory category, float volume, float pitch) {}

	@Override
	public void playSound(@Nullable PlayerEntity p_217384_1_, Entity p_217384_2_, SoundEvent p_217384_3_,
		SoundCategory p_217384_4_, float p_217384_5_, float p_217384_6_) {}

	@Override
	public Entity getEntity(int id) {
		return null;
	}

	@Override
	public MapState getMapData(String mapName) {
		return null;
	}

	@Override
	public boolean addFreshEntity(Entity entityIn) {
		((EntityAccessor) entityIn).catnip$callSetLevel(level);
		return level.addFreshEntity(entityIn);
	}

	@Override
	public void setMapData(String pMapId, MapState pData) {}

	@Override
	public int getFreeMapId() {
		return level.getFreeMapId();
	}

	@Override
	public void destroyBlockProgress(int breakerId, BlockPos pos, int progress) {}

	@Override
	public Scoreboard getScoreboard() {
		return level.getScoreboard();
	}

	@Override
	public RecipeManager getRecipeManager() {
		return level.getRecipeManager();
	}

	@Override
	public RegistryEntry<Biome> getUncachedNoiseBiome(int p_225604_1_, int p_225604_2_, int p_225604_3_) {
		return level.getUncachedNoiseBiome(p_225604_1_, p_225604_2_, p_225604_3_);
	}

	@Override
	public DynamicRegistryManager registryAccess() {
		return level.registryAccess();
	}

	@Override
	public float getShade(Direction p_230487_1_, boolean p_230487_2_) {
		return level.getShade(p_230487_1_, p_230487_2_);
	}

	@Override
	public void updateNeighbourForOutputSignal(BlockPos p_175666_1_, Block p_175666_2_) {}

	@Override
	public void gameEvent(Entity pEntity, GameEvent pEvent, BlockPos pPos) {}

	@Override
	public void gameEvent(GameEvent p_220404_, Vec3d p_220405_, GameEvent.Emitter p_220406_) {}

	@Override
	public String gatherChunkSourceStats() {
		return level.gatherChunkSourceStats();
	}

	@Override
	protected EntityLookup<Entity> getEntities() {
		return entityGetter;
	}

	// Intentionally copied from LevelHeightAccessor. Workaround for issues caused
	// when other mods (such as Lithium)
	// override the vanilla implementations in ways which cause WrappedWorlds to
	// return incorrect, default height info.
	// WrappedWorld subclasses should implement their own getMinBuildHeight and
	// getHeight overrides where they deviate
	// from the defaults for their dimension.

	@Override
	public int getMaxBuildHeight() {
		return this.getMinBuildHeight() + this.getHeight();
	}

	@Override
	public int getSectionsCount() {
		return this.getMaxSection() - this.getMinSection();
	}

	@Override
	public int getMinSection() {
		return ChunkSectionPos.blockToSectionCoord(this.getMinBuildHeight());
	}

	@Override
	public int getMaxSection() {
		return ChunkSectionPos.blockToSectionCoord(this.getMaxBuildHeight() - 1) + 1;
	}

	@Override
	public boolean isOutsideBuildHeight(BlockPos pos) {
		return this.isOutsideBuildHeight(pos.getY());
	}

	@Override
	public boolean isOutsideBuildHeight(int y) {
		return y < this.getMinBuildHeight() || y >= this.getMaxBuildHeight();
	}

	@Override
	public int getSectionIndex(int y) {
		return this.getSectionIndexFromSectionY(ChunkSectionPos.blockToSectionCoord(y));
	}

	@Override
	public int getSectionIndexFromSectionY(int sectionY) {
		return sectionY - this.getMinSection();
	}

	@Override
	public int getSectionYFromSectionIndex(int sectionIndex) {
		return sectionIndex + this.getMinSection();
	}

	@Override
	public FeatureSet enabledFeatures() {
		return level.enabledFeatures();
	}
}
