package net.createmod.catnip.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.util.Identifier;

public interface BindableTexture {

	default void bind() {
		RenderSystem.setShaderTexture(0, getLocation());
	}

	Identifier getLocation();

}
