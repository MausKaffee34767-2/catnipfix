package net.createmod.ponder.foundation.element;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.ponder.api.element.AnimatedSceneElement;
import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public abstract class AnimatedSceneElementBase extends PonderElementBase implements AnimatedSceneElement {

	protected Vec3d fadeVec;
	protected LerpedFloat fade;

	public AnimatedSceneElementBase() {
		fade = LerpedFloat.linear()
			.startWithValue(0);
	}

	@Override
	public void forceApplyFade(float fade) {
		this.fade.startWithValue(fade);
	}

	@Override
	public void setFade(float fade) {
		this.fade.setValue(fade);
	}

	@Override
	public void setFadeVec(Vec3d fadeVec) {
		this.fadeVec = fadeVec;
	}

	@Override
	public final void renderFirst(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt) {
		MatrixStack poseStack = graphics.pose();
		poseStack.pushPose();
		float currentFade = applyFade(poseStack, pt);
		renderFirst(world, buffer, graphics, currentFade, pt);
		poseStack.popPose();
	}

	@Override
	public final void renderLayer(PonderLevel world, VertexConsumerProvider buffer, RenderLayer type, DrawContext graphics,
								  float pt) {
		MatrixStack poseStack = graphics.pose();
		poseStack.pushPose();
		float currentFade = applyFade(poseStack, pt);
		renderLayer(world, buffer, type, graphics, currentFade, pt);
		poseStack.popPose();
	}

	@Override
	public final void renderLast(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt) {
		MatrixStack poseStack = graphics.pose();
		poseStack.pushPose();
		float currentFade = applyFade(poseStack, pt);
		renderLast(world, buffer, graphics, currentFade, pt);
		poseStack.popPose();
	}

	protected float applyFade(MatrixStack ms, float pt) {
		float currentFade = fade.getValue(pt);
		if (fadeVec != null) {
			Vec3d scaled = fadeVec.scale(-1 + currentFade);
			ms.translate(scaled.x, scaled.y, scaled.z);
		}

		return currentFade;
	}

	protected void renderLayer(PonderLevel world, VertexConsumerProvider buffer, RenderLayer type, DrawContext graphics, float fade,
							   float pt) {}

	protected void renderFirst(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float fade, float pt) {}

	protected void renderLast(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float fade, float pt) {}

	protected int lightCoordsFromFade(float fade) {
		int light = LightTexture.FULL_BRIGHT;
		if (fade != 1) {
			light = (int) (MathHelper.lerp(fade, 5, 0xF));
			light = LightmapTextureManager.pack(light, light);
		}
		return light;
	}

}
