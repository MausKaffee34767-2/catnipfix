package net.createmod.catnip.platform;

import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.platform.services.RegisteredObjectsHelper;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.EntityType;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleType;
import net.minecraft.potion.Potion;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;

public class ForgeRegisteredObjectsHelper implements RegisteredObjectsHelper<IForgeRegistry> {

	@Override
	public <V> Identifier getKeyOrThrow(IForgeRegistry registry, V value) {
		Identifier key = registry.getKey(value);

		if (key == null) {
			throw new IllegalArgumentException("Could not get key for value " + value + "!");
		}

		return key;
	}

	@Override
	public Identifier getKeyOrThrow(Block value) {
		return getKeyOrThrow(ForgeRegistries.BLOCKS, value);
	}

	@Override
	public Identifier getKeyOrThrow(Item value) {
		return getKeyOrThrow(ForgeRegistries.ITEMS, value);
	}

	@Override
	public Identifier getKeyOrThrow(Fluid value) {
		return getKeyOrThrow(ForgeRegistries.FLUIDS, value);
	}

	@Override
	public Identifier getKeyOrThrow(EntityType<?> value) {
		return getKeyOrThrow(ForgeRegistries.ENTITY_TYPES, value);
	}

	@Override
	public Identifier getKeyOrThrow(BlockEntityType<?> value) {
		return getKeyOrThrow(ForgeRegistries.BLOCK_ENTITY_TYPES, value);
	}

	@Override
	public Identifier getKeyOrThrow(Potion value) {
		return getKeyOrThrow(ForgeRegistries.POTIONS, value);
	}

	@Override
	public Identifier getKeyOrThrow(ParticleType<?> value) {
		return getKeyOrThrow(ForgeRegistries.PARTICLE_TYPES, value);
	}

	@Override
	public Identifier getKeyOrThrow(RecipeSerializer<?> value) {
		return getKeyOrThrow(ForgeRegistries.RECIPE_SERIALIZERS, value);
	}

	@Nullable
	@Override
	public Item getItem(Identifier location) {
		return ForgeRegistries.ITEMS.getValue(location);
	}

	@Nullable
	@Override
	public Block getBlock(Identifier location) {
		return ForgeRegistries.BLOCKS.getValue(location);
	}
}
