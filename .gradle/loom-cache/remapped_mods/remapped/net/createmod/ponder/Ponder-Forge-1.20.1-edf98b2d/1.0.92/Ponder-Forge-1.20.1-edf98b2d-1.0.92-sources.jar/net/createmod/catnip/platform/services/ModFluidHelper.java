package net.createmod.catnip.platform.services;

import net.createmod.catnip.annotations.ClientOnly;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.Sprite;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.jetbrains.annotations.Nullable;

public interface ModFluidHelper<R> {
	@ClientOnly
	int getColor(R fluid, @Nullable BlockRenderView level, @Nullable BlockPos pos);

	int getLuminosity(R fluid);

	@ClientOnly
	@Nullable
	Sprite getStillTexture(R fluid);

	@ClientOnly
	default Sprite getStillTextureOrMissing(R fluid) {
		Sprite texture = this.getStillTexture(fluid);
		if (texture != null)
			return texture;

		return MinecraftClient.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(MissingSprite.getLocation());
	}

	boolean isLighterThanAir(R fluid);

	R toStack(FluidState state);
}
