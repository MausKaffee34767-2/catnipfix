package net.createmod.catnip.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import net.createmod.ponder.Ponder;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.network.packet.s2c.play.PlayerAbilitiesS2CPacket;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

public class FlySpeedCommand {

	public static ArgumentBuilder<ServerCommandSource, ?> register() {
		return CommandManager.literal("flySpeed")
			.requires(cs -> cs.hasPermission(2))
			.then(CommandManager.argument("speed", FloatArgumentType.floatArg(0))
				.then(CommandManager.argument("target", EntityArgumentType.player())
					.executes(ctx -> sendFlySpeedUpdate(ctx, EntityArgument.getPlayer(ctx, "target"),
						FloatArgumentType.getFloat(ctx, "speed"))))
				.executes(ctx -> sendFlySpeedUpdate(ctx, ctx.getSource()
					.getPlayerOrException(), FloatArgumentType.getFloat(ctx, "speed"))))
			.then(CommandManager.literal("reset")
				.then(CommandManager.argument("target", EntityArgumentType.player())
					.executes(ctx -> sendFlySpeedUpdate(ctx, EntityArgument.getPlayer(ctx, "target"), 0.05f)))
				.executes(ctx -> sendFlySpeedUpdate(ctx, ctx.getSource()
					.getPlayerOrException(), 0.05f))

			);
	}

	private static int sendFlySpeedUpdate(CommandContext<ServerCommandSource> ctx, ServerPlayerEntity player, float speed) {
		PlayerAbilities abilities = player.getAbilities();
		abilities.setFlyingSpeed(speed);
		player.connection.send(new PlayerAbilitiesS2CPacket(abilities));
		ctx.getSource().sendSuccess(() ->
			Component.literal("[Catnip]: ").withStyle(ChatFormatting.YELLOW).append(Component.translatable("catnip.util.fly_speed_set.message", player.getName().copy(), speed).withStyle(ChatFormatting.WHITE)),
				true
		);

		return Command.SINGLE_SUCCESS;
	}

}
