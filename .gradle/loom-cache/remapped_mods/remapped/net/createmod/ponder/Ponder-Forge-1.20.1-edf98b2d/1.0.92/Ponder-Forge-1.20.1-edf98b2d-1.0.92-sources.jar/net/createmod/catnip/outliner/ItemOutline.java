package net.createmod.catnip.outliner;

import net.createmod.catnip.render.SuperRenderTypeBuffer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

public class ItemOutline extends Outline {

	protected Vec3d pos;
	protected ItemStack stack;

	public ItemOutline(Vec3d pos, ItemStack stack) {
		this.pos = pos;
		this.stack = stack;
	}

	@Override
	public void render(MatrixStack ms, SuperRenderTypeBuffer buffer, Vec3d camera, float pt) {
		MinecraftClient mc = MinecraftClient.getInstance();
		ms.pushPose();

		ms.translate(pos.x - camera.x, pos.y - camera.y, pos.z - camera.z);
		ms.scale(params.alpha, params.alpha, params.alpha);

		mc.getItemRenderer().render(stack, ModelTransformationMode.FIXED, false, ms,
									buffer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
									mc.getItemRenderer().getModel(stack, null, null, 0));

		ms.popPose();
	}
}
