package net.createmod.ponder.command;

import java.util.Collection;

import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.ArgumentBuilder;

import net.createmod.catnip.net.ClientboundSimpleActionPacket;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

public class PonderCommand {
	//public static final SuggestionProvider<CommandSourceStack> ITEM_PONDERS = SuggestionProviders.register(new ResourceLocation("all_ponders"), (iSuggestionProviderCommandContext, builder) -> SharedSuggestionProvider.suggestResource(PonderRegistry.ALL.keySet().stream(), builder));
	//TODO PonderRegistry can't be loaded on Server Dist

	static ArgumentBuilder<ServerCommandSource, ?> register() {
		return CommandManager.literal("ponder")
				.requires(cs -> cs.hasPermission(0))
				.executes(ctx -> openScene("ponder:tags", ctx.getSource().getPlayerOrException()))
				.then(CommandManager.literal("reload")
							  .executes(ctx -> reloadPonderIndex(ctx.getSource().getPlayerOrException()))
				)
				.then(CommandManager.literal("index")
							  .executes(ctx -> openScene("ponder:index", ctx.getSource().getPlayerOrException()))
				)
				.then(CommandManager.literal("tags")
							  .executes(ctx -> openScene("ponder:tags", ctx.getSource().getPlayerOrException()))
				)
				.then(CommandManager.argument("scene", IdentifierArgumentType.id())
							  //.suggests(ITEM_PONDERS)
							  .executes(ctx -> openScene(ResourceLocationArgument.getId(ctx, "scene").toString(),
														 ctx.getSource().getPlayerOrException()))
							  .then(CommandManager.argument("targets", EntityArgumentType.players())
											.requires(cs -> cs.hasPermission(2))
											.executes(ctx -> openScene(
													ResourceLocationArgument.getId(ctx, "scene").toString(),
													EntityArgument.getPlayers(ctx, "targets")))
							  )
				);

	}

	private static int openScene(String sceneId, ServerPlayerEntity player) {
		return openScene(sceneId, ImmutableList.of(player));
	}

	private static int openScene(String sceneId, Collection<? extends ServerPlayerEntity> players) {
		for (ServerPlayerEntity player : players) {
			if (CatnipServices.HOOKS.isPlayerFake(player))
				continue;

			CatnipServices.NETWORK.sendToPlayer(
					player,
					new ClientboundSimpleActionPacket("openPonder", sceneId)
			);
		}
		return Command.SINGLE_SUCCESS;
	}

	private static int reloadPonderIndex(ServerPlayerEntity player) {
		CatnipServices.NETWORK.simpleActionToClient(player, "reloadPonder", "");

		return Command.SINGLE_SUCCESS;
	}
}
