package net.createmod.ponder.api.element;

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;

public interface PonderSceneElement extends PonderElement {

	void renderFirst(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt);

	void renderLayer(PonderLevel world, VertexConsumerProvider buffer, RenderLayer type, DrawContext graphics, float pt);

	void renderLast(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt);

}
