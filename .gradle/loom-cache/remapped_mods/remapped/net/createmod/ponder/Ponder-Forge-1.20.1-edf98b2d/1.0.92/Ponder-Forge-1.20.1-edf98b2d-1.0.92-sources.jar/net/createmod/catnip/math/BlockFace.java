package net.createmod.catnip.math;

import net.createmod.catnip.data.Pair;
import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class BlockFace extends Pair<BlockPos, Direction> {

	public BlockFace(BlockPos first, Direction second) {
		super(first, second);
	}

	public boolean isEquivalent(BlockFace other) {
		if (equals(other))
			return true;
		return getConnectedPos().equals(other.getPos()) && getPos().equals(other.getConnectedPos());
	}

	public BlockPos getPos() {
		return getFirst();
	}

	public Direction getFace() {
		return getSecond();
	}

	public Direction getOppositeFace() {
		return getSecond().getOpposite();
	}

	public BlockFace getOpposite() {
		return new BlockFace(getConnectedPos(), getOppositeFace());
	}

	public BlockPos getConnectedPos() {
		return getPos().relative(getFace());
	}

	public NbtCompound serializeNBT() {
		NbtCompound compoundNBT = new NbtCompound();
		compoundNBT.put("Pos", NbtHelper.writeBlockPos(getPos()));
		NBTHelper.writeEnum(compoundNBT, "Face", getFace());
		return compoundNBT;
	}

	public static BlockFace fromNBT(NbtCompound compound) {
		return new BlockFace(NbtHelper.readBlockPos(compound.getCompound("Pos")),
			NBTHelper.readEnum(compound, "Face", Direction.class));
	}

}
