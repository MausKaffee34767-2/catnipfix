package net.createmod.catnip.client;

import net.createmod.catnip.platform.services.ModClientHooksHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/**
 * Marker class for a {@link KeyBinding} that is not registered to {@link KeyBinding#MAP} on Fabric.
 * On Forge, this is no difference between an instance of this class and a normal {@link KeyBinding}.
 * <p>
 * Normal keybind features such as {@link KeyBinding#isDown() isDown} and {@link KeyBinding#consumeClick() consumeClick}
 * will be unreliable. Instead, use {@link ModClientHooksHelper#isKeyPressed(KeyBinding) isKeyPressed}.
 * <p>
 * This is done to avoid conflicting with vanilla keybinds. Forge handles that case fine already.
 * <p>
 * This workaround will be fully obsolete on 1.21.9 or newer.
 */
// TODO: Port - Remove in 1.21.9+
@SuppressWarnings("JavadocReference")
public class ConflictSafeKeyMapping extends KeyBinding {
	public ConflictSafeKeyMapping(String description, int defaultKey, String category) {
		super(description, defaultKey, category);
	}

	public ConflictSafeKeyMapping(String description, InputUtil.Type type, int defaultKey, String category) {
		super(description, type, defaultKey, category);
	}
}
