package net.createmod.catnip.render;

import java.util.function.BiFunction;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.enums.PonderSpecialTextures;
import net.createmod.ponder.mixin.client.accessor.RenderTypeAccessor;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

public abstract class PonderRenderTypes extends RenderLayer {

	private static final RenderLayer OUTLINE_SOLID =
		RenderTypeAccessor.catnip$create(createLayerName("outline_solid"), DefaultVertexFormat.NEW_ENTITY, VertexFormat.DrawMode.QUADS, 256, false, false, RenderLayer.MultiPhaseParameters.builder()
			.setShaderState(RENDERTYPE_ENTITY_SOLID_SHADER)
			.setTextureState(new RenderPhase.Texture(PonderSpecialTextures.BLANK.getLocation(), false, false))
			.setCullState(CULL)
			.setLightmapState(LIGHTMAP)
			.setOverlayState(OVERLAY)
			.createCompositeState(false));

	private static final BiFunction<Identifier, Boolean, RenderLayer> OUTLINE_TRANSLUCENT = Util.memoize((texture, cull) ->
		RenderTypeAccessor.catnip$create(createLayerName("outline_translucent" + (cull ? "_cull" : "")), DefaultVertexFormat.NEW_ENTITY, VertexFormat.Mode.QUADS, 256, false, true, CompositeState.builder()
			.setShaderState(cull ? RENDERTYPE_ENTITY_TRANSLUCENT_CULL_SHADER : RENDERTYPE_ENTITY_TRANSLUCENT_SHADER)
			.setTextureState(new TextureStateShard(texture, false, false))
			.setTransparencyState(TRANSLUCENT_TRANSPARENCY)
			.setCullState(cull ? CULL : NO_CULL)
			.setLightmapState(LIGHTMAP)
			.setOverlayState(OVERLAY)
			.setWriteMaskState(COLOR_WRITE)
			.createCompositeState(false)));

	private static final RenderLayer FLUID =
		RenderTypeAccessor.catnip$create(createLayerName("fluid"), DefaultVertexFormat.BLOCK, VertexFormat.DrawMode.QUADS, 256, false, true, RenderLayer.MultiPhaseParameters.builder()
			.setShaderState(RENDERTYPE_TRANSLUCENT_SHADER)
			.setTextureState(BLOCK_SHEET_MIPPED)
			.setTransparencyState(TRANSLUCENT_TRANSPARENCY)
			.setLightmapState(LIGHTMAP)
			//.setOverlayState(NO_OVERLAY)
			.createCompositeState(true));

	public static RenderLayer outlineSolid() {
		return OUTLINE_SOLID;
	}

	public static RenderLayer outlineTranslucent(Identifier texture, boolean cull) {
		return OUTLINE_TRANSLUCENT.apply(texture, cull);
	}

	//TODO vanilla uses the translucent render type for fluids, need to investigate if this is even needed
	public static RenderLayer fluid() {
		return FLUID;
	}

	private static String createLayerName(String name) {
		return Ponder.MOD_ID + ":" + name;
	}

	private PonderRenderTypes(String name, VertexFormat format, VertexFormat.DrawMode mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setupState, Runnable clearState) {
		super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
	}
}
