package net.createmod.catnip.platform;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.platform.services.ModFluidHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.Sprite;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.fluids.FluidStack;

public class ForgeFluidHelper implements ModFluidHelper<FluidStack> {
	@OnlyIn(Dist.CLIENT)
	@Override
	public int getColor(FluidStack stack, @Nullable BlockRenderView level, @Nullable BlockPos pos) {
		Fluid fluid = stack.getFluid();
		IClientFluidTypeExtensions extension = IClientFluidTypeExtensions.of(fluid);
		if (level == null || pos == null)
			return extension.getTintColor(stack);
		return extension.getTintColor(fluid.defaultFluidState(), level, pos);
	}

	@Override
	public int getLuminosity(FluidStack fluid) {
		return fluid.getFluid().getFluidType().getLightLevel();
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	@Nullable
	public Sprite getStillTexture(FluidStack fluid) {
		Identifier id = IClientFluidTypeExtensions.of(fluid.getFluid()).getStillTexture(fluid);
		return id == null ? null : MinecraftClient.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(id);
	}

	@Override
	public boolean isLighterThanAir(FluidStack fluid) {
		return fluid.getFluid().getFluidType().isLighterThanAir();
	}

	@Override
	public FluidStack toStack(FluidState state) {
		return new FluidStack(state.getType(), 1000);
	}
}
