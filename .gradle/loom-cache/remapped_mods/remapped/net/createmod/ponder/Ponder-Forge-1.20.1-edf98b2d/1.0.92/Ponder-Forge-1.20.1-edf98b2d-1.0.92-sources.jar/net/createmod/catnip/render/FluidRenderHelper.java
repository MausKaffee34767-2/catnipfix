package net.createmod.catnip.render;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.platform.services.ModFluidHelper;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public final class FluidRenderHelper<T> {
	public void renderFluidBox(FluidState fluid, float xMin, float yMin, float zMin, float xMax, float yMax, float zMax,
							   VertexConsumerProvider buffer, MatrixStack ms, int light, boolean renderBottom, boolean invertGasses) {
		this.renderFluidBox(fluid, xMin, yMin, zMin, xMax, yMax, zMax, getFluidBuilder(buffer), ms, light, renderBottom, invertGasses);
	}

	public void renderFluidBox(FluidState fluid, float xMin, float yMin, float zMin, float xMax, float yMax, float zMax,
							   VertexConsumer builder, MatrixStack ms, int light, boolean renderBottom, boolean invertGasses) {
		this.renderFluidBox(this.helper().toStack(fluid), xMin, yMin, zMin, xMax, yMax, zMax, builder, ms, light, renderBottom, invertGasses);
	}

	public void renderFluidBox(T fluid, float xMin, float yMin, float zMin, float xMax, float yMax, float zMax,
			VertexConsumerProvider buffer, MatrixStack ms, int light, boolean renderBottom, boolean invertGasses) {
		this.renderFluidBox(fluid, xMin, yMin, zMin, xMax, yMax, zMax, getFluidBuilder(buffer), ms, light, renderBottom, invertGasses);
	}

	public void renderFluidBox(T fluid, float xMin, float yMin, float zMin, float xMax, float yMax, float zMax,
			VertexConsumer builder, MatrixStack ms, int light, boolean renderBottom, boolean invertGasses) {
		ModFluidHelper<T> helper = this.helper();

		Sprite fluidTexture = helper.getStillTextureOrMissing(fluid);
		int color = helper.getColor(fluid, null, null);

		int blockLightIn = (light >> 4) & 0xF;
		int luminosity = Math.max(blockLightIn, helper.getLuminosity(fluid));
		light = (light & 0xF00000) | luminosity << 4;

		Vec3d center = new Vec3d(xMin + (xMax - xMin) / 2, yMin + (yMax - yMin) / 2, zMin + (zMax - zMin) / 2);
		ms.pushPose();
		if (invertGasses && helper.isLighterThanAir(fluid)) {
			ms.translate(center.x, center.y, center.z);
			ms.mulPose(Axis.XP.rotationDegrees(180));
			ms.translate(-center.x, -center.y, -center.z);
		}

		for (Direction side : Iterate.directions) {
			if (side == Direction.DOWN && !renderBottom)
				continue;

			boolean positive = side.getAxisDirection() == Direction.AxisDirection.POSITIVE;
			if (side.getAxis()
					.isHorizontal()) {
				if (side.getAxis() == Direction.Axis.X) {
					renderStillTiledFace(side, zMin, yMin, zMax, yMax, positive ? xMax : xMin,
							builder, ms, light, color, fluidTexture);
				} else {
					renderStillTiledFace(side, xMin, yMin, xMax, yMax, positive ? zMax : zMin,
							builder, ms, light, color, fluidTexture);
				}
			} else {
				renderStillTiledFace(side, xMin, zMin, xMax, zMax, positive ? yMax : yMin,
						builder, ms, light, color, fluidTexture);
			}
		}

		ms.popPose();
	}

	public static VertexConsumer getFluidBuilder(VertexConsumerProvider buffer) {
		return buffer.getBuffer(PonderRenderTypes.fluid());
	}

	public static void renderStillTiledFace(Direction dir, float left, float down, float right, float up,
			float depth, VertexConsumer builder, MatrixStack ms, int light, int color, Sprite texture) {
		renderTiledFace(dir, left, down, right, up, depth, builder, ms, light, color, texture, 1);
	}

	public static void renderTiledFace(Direction dir, float left, float down, float right, float up,
			float depth, VertexConsumer builder, MatrixStack ms, int light, int color, Sprite texture,
			float textureScale) {
		boolean positive = dir.getAxisDirection() == Direction.AxisDirection.POSITIVE;
		boolean horizontal = dir.getAxis().isHorizontal();
		boolean x = dir.getAxis() == Direction.Axis.X;

		float shrink = texture.uvShrinkRatio() * 0.25f * textureScale;
		float centerU = texture.getU0() + (texture.getU1() - texture.getU0()) * 0.5f * textureScale;
		float centerV = texture.getV0() + (texture.getV1() - texture.getV0()) * 0.5f * textureScale;

		float f;
		float x2 = 0;
		float y2 = 0;
		float u1, u2;
		float v1, v2;
		for (float x1 = left; x1 < right; x1 = x2) {
			f = MathHelper.floor(x1);
			x2 = Math.min(f + 1, right);
			if (dir == Direction.NORTH || dir == Direction.EAST) {
				f = MathHelper.ceil(x2);
				u1 = texture.getU((f - x2) * 16 * textureScale);
				u2 = texture.getU((f - x1) * 16 * textureScale);
			} else {
				u1 = texture.getU((x1 - f) * 16 * textureScale);
				u2 = texture.getU((x2 - f) * 16 * textureScale);
			}
			u1 = MathHelper.lerp(shrink, u1, centerU);
			u2 = MathHelper.lerp(shrink, u2, centerU);
			for (float y1 = down; y1 < up; y1 = y2) {
				f = MathHelper.floor(y1);
				y2 = Math.min(f + 1, up);
				if (dir == Direction.UP) {
					v1 = texture.getV((y1 - f) * 16 * textureScale);
					v2 = texture.getV((y2 - f) * 16 * textureScale);
				} else {
					f = MathHelper.ceil(y2);
					v1 = texture.getV((f - y2) * 16 * textureScale);
					v2 = texture.getV((f - y1) * 16 * textureScale);
				}
				v1 = MathHelper.lerp(shrink, v1, centerV);
				v2 = MathHelper.lerp(shrink, v2, centerV);

				if (horizontal) {
					if (x) {
						putVertex(builder, ms, depth, y2, positive ? x2 : x1, color, u1, v1, dir, light);
						putVertex(builder, ms, depth, y1, positive ? x2 : x1, color, u1, v2, dir, light);
						putVertex(builder, ms, depth, y1, positive ? x1 : x2, color, u2, v2, dir, light);
						putVertex(builder, ms, depth, y2, positive ? x1 : x2, color, u2, v1, dir, light);
					} else {
						putVertex(builder, ms, positive ? x1 : x2, y2, depth, color, u1, v1, dir, light);
						putVertex(builder, ms, positive ? x1 : x2, y1, depth, color, u1, v2, dir, light);
						putVertex(builder, ms, positive ? x2 : x1, y1, depth, color, u2, v2, dir, light);
						putVertex(builder, ms, positive ? x2 : x1, y2, depth, color, u2, v1, dir, light);
					}
				} else {
					putVertex(builder, ms, x1, depth, positive ? y1 : y2, color, u1, v1, dir, light);
					putVertex(builder, ms, x1, depth, positive ? y2 : y1, color, u1, v2, dir, light);
					putVertex(builder, ms, x2, depth, positive ? y2 : y1, color, u2, v2, dir, light);
					putVertex(builder, ms, x2, depth, positive ? y1 : y2, color, u2, v1, dir, light);
				}
			}
		}
	}

	private static void putVertex(VertexConsumer builder, MatrixStack ms, float x, float y, float z, int color, float u,
			float v, Direction face, int light) {

		Vec3i normal = face.getNormal();
		MatrixStack.Entry peek = ms.last();
		int a = color >> 24 & 0xff;
		int r = color >> 16 & 0xff;
		int g = color >> 8 & 0xff;
		int b = color & 0xff;

		builder.vertex(peek.pose(), x, y, z)
				.color(r, g, b, a)
				.uv(u, v)
				//.overlayCoords(OverlayTexture.NO_OVERLAY)
				.uv2(light)
				.normal(peek.normal(), normal.getX(), normal.getY(), normal.getZ())
				.endVertex();
	}

	@SuppressWarnings("unchecked")
	private ModFluidHelper<T> helper() {
		return (ModFluidHelper<T>) CatnipServices.FLUID_HELPER;
	}
}
