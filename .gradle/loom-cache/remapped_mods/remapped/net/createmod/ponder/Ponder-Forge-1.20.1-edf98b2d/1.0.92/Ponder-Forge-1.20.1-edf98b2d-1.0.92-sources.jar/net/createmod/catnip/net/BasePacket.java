package net.createmod.catnip.net;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public interface BasePacket {

	void write(PacketByteBuf buffer);

	Identifier getId();

}
