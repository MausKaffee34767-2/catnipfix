package net.createmod.catnip.gui.element;

import net.minecraft.client.gui.DrawContext;

public interface ScreenElement {

	void render(DrawContext graphics, int x, int y);
}
