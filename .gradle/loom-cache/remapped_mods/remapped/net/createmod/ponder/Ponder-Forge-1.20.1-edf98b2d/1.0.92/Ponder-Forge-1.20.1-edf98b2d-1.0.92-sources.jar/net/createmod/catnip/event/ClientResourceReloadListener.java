package net.createmod.catnip.event;

import net.createmod.catnip.lang.LangNumberFormat;
import net.createmod.ponder.PonderClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.SynchronousResourceReloader;

public class ClientResourceReloadListener implements SynchronousResourceReloader {

	@Override
	public void onResourceManagerReload(ResourceManager resourceManager) {
		LangNumberFormat.numberFormat.update();
		PonderClient.invalidateRenderers();
	}

}
