package net.createmod.ponder.render;

import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;

@Deprecated(forRemoval = true)
public class ForgeShadedBlockSbbBuilder extends ShadedBlockSbbBuilder implements VertexConsumer {

	public ForgeShadedBlockSbbBuilder(BufferBuilder bufferBuilder) {
		super(bufferBuilder);
	}

	@Override
	public void putBulkData(MatrixStack.Entry pose, BakedQuad quad, float red, float green, float blue, float alpha, int light, int overlay, boolean readExistingColor) {
		prepareForGeometry(quad);
		bufferBuilder.putBulkData(pose, quad, red, green, blue, alpha, light, overlay, readExistingColor);
	}

	@Override
	public void putBulkData(MatrixStack.Entry pose, BakedQuad quad, float[] brightnesses, float red, float green, float blue, float alpha, int[] lights, int overlay, boolean readExistingColor) {
		prepareForGeometry(quad);
		bufferBuilder.putBulkData(pose, quad, brightnesses, red, green, blue, alpha, lights, overlay, readExistingColor);
	}

}
