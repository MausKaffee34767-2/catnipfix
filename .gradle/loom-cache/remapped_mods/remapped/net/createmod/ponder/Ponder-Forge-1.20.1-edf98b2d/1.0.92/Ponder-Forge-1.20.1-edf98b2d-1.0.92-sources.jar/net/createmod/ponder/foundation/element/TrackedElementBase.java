package net.createmod.ponder.foundation.element;

import java.lang.ref.WeakReference;
import java.util.function.Consumer;

import net.createmod.ponder.api.element.TrackedElement;
import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;

public abstract class TrackedElementBase<T> extends PonderElementBase implements TrackedElement<T> {

	private final WeakReference<T> reference;

	public TrackedElementBase(T wrapped) {
		this.reference = new WeakReference<>(wrapped);
	}

	@Override
	public void ifPresent(Consumer<T> func) {
		T resolved = reference.get();
		if (resolved == null)
			return;
		func.accept(resolved);
	}

	@Override
	public void renderFirst(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt) {}

	@Override
	public void renderLayer(PonderLevel world, VertexConsumerProvider buffer, RenderLayer type, DrawContext graphics, float pt) {}

	@Override
	public void renderLast(PonderLevel world, VertexConsumerProvider buffer, DrawContext graphics, float pt) {}

}
