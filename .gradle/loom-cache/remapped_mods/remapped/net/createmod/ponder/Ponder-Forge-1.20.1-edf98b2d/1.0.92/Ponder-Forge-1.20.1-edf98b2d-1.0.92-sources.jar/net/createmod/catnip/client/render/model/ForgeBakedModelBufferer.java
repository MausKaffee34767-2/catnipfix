package net.createmod.catnip.client.render.model;

import java.util.Iterator;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;
import net.createmod.catnip.impl.client.render.model.BakedModelBuffererImpl;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraftforge.client.model.data.ModelData;

public final class ForgeBakedModelBufferer {
	private ForgeBakedModelBufferer() {
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, @Nullable ModelData modelData, ShadeSeparatedBufferSource bufferSource) {
		BakedModelBuffererImpl.bufferModel(model, pos, level, state, poseStack, modelData, bufferSource);
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, @Nullable ModelData modelData, ShadeSeparatedResultConsumer resultConsumer) {
		BakedModelBuffererImpl.bufferModel(model, pos, level, state, poseStack, modelData, resultConsumer);
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, @Nullable Function<BlockPos, ModelData> modelDataLookup, boolean renderFluids, ShadeSeparatedBufferSource bufferSource) {
		BakedModelBuffererImpl.bufferBlocks(posIterator, level, poseStack, modelDataLookup, renderFluids, bufferSource);
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, @Nullable Function<BlockPos, ModelData> modelDataLookup, boolean renderFluids, ShadeSeparatedResultConsumer resultConsumer) {
		BakedModelBuffererImpl.bufferBlocks(posIterator, level, poseStack, modelDataLookup, renderFluids, resultConsumer);
	}
}
