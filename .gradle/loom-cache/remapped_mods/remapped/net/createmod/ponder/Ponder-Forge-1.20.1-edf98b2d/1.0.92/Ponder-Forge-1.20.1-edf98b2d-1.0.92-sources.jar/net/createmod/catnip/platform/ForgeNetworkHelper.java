package net.createmod.catnip.platform;

import net.createmod.catnip.net.BasePacket;
import net.createmod.catnip.platform.services.NetworkHelper;
import net.createmod.ponder.net.ForgePonderNetwork;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.network.PacketDistributor;

public class ForgeNetworkHelper implements NetworkHelper {

	@Override
	public void sendToPlayer(PlayerEntity player, BasePacket packet) {
		if (!(player instanceof ServerPlayerEntity serverPlayer))
			return;

		ForgePonderNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> serverPlayer), packet);
	}

	@Override
	public void sendToNear(World level, BlockPos pos, int range, BasePacket packet) {
		ForgePonderNetwork.CHANNEL.send(PacketDistributor.NEAR.with(
				PacketDistributor.TargetPoint.p(pos.getX(), pos.getY(), pos.getZ(), range, level.dimension())),
				packet
		);
	}

	@Override
	public void sendToEntity(Entity entity, BasePacket packet) {
		ForgePonderNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> entity), packet);
	}

	@Override
	public void sendToServer(BasePacket packet) {
		ForgePonderNetwork.CHANNEL.sendToServer(packet);
	}
}
