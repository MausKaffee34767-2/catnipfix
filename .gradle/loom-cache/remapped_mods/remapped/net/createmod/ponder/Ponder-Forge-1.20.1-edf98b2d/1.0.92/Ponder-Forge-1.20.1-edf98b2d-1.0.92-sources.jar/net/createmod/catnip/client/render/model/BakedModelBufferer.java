package net.createmod.catnip.client.render.model;

import java.util.Iterator;

import org.jetbrains.annotations.Nullable;
import net.createmod.catnip.platform.CatnipClientServices;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;

public final class BakedModelBufferer {
	private BakedModelBufferer() {
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedBufferSource bufferSource) {
		CatnipClientServices.CLIENT_HOOKS.bufferModel(model, pos, level, state, poseStack, bufferSource);
	}

	public static void bufferModel(BakedModel model, BlockPos pos, BlockRenderView level, BlockState state, @Nullable MatrixStack poseStack, ShadeSeparatedResultConsumer resultConsumer) {
		CatnipClientServices.CLIENT_HOOKS.bufferModel(model, pos, level, state, poseStack, resultConsumer);
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedBufferSource bufferSource) {
		CatnipClientServices.CLIENT_HOOKS.bufferBlocks(posIterator, level, poseStack, renderFluids, bufferSource);
	}

	public static void bufferBlocks(Iterator<BlockPos> posIterator, BlockRenderView level, @Nullable MatrixStack poseStack, boolean renderFluids, ShadeSeparatedResultConsumer resultConsumer) {
		CatnipClientServices.CLIENT_HOOKS.bufferBlocks(posIterator, level, poseStack, renderFluids, resultConsumer);
	}
}
