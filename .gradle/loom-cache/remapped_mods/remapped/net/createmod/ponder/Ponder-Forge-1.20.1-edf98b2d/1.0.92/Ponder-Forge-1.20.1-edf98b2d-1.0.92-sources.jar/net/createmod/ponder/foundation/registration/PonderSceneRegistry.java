package net.createmod.ponder.foundation.registration;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.zip.GZIPInputStream;

import javax.annotation.Nullable;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;

import net.createmod.ponder.Ponder;
import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.api.registration.SceneRegistryAccess;
import net.createmod.ponder.api.registration.StoryBoardEntry;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.client.MinecraftClient;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtTagSizeTracker;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.Identifier;

public class PonderSceneRegistry implements SceneRegistryAccess {

	private final PonderLocalization localization;
	private final Multimap<Identifier, StoryBoardEntry> scenes;

	private boolean allowRegistration = true;

	public PonderSceneRegistry(PonderLocalization localization) {
		this.localization = localization;
		scenes = LinkedHashMultimap.create();
	}

	public void clearRegistry() {
		scenes.clear();
		allowRegistration = true;
	}

	//

	public void addStoryBoard(StoryBoardEntry entry) {
		if (!allowRegistration)
			throw new IllegalStateException("Registration Phase has already ended!");

		scenes.put(entry.getComponent(), entry);
	}

	//

	@Override
	public Collection<Map.Entry<Identifier, StoryBoardEntry>> getRegisteredEntries() {
		return scenes.entries();
	}

	@Override
	public boolean doScenesExistForId(Identifier id) {
		return scenes.containsKey(id);
	}

	//

	@Override
	public List<PonderScene> compile(Identifier id) {
		if (PonderIndex.editingModeActive())
			PonderIndex.reload();

		Collection<StoryBoardEntry> entries = scenes.get(id);

		if (entries.isEmpty()) return Collections.emptyList();

		return compile(entries);

	}

	@Override
	public List<PonderScene> compile(Collection<StoryBoardEntry> entries) {
		if (PonderIndex.editingModeActive()) {
			localization.clearShared();
			PonderIndex.gatherSharedText();
		}

		List<PonderScene> scenes = new ArrayList<>();

		for (StoryBoardEntry storyBoard : entries) {
			StructureTemplate activeTemplate = loadSchematic(storyBoard.getSchematicLocation());
			PonderLevel level = new PonderLevel(BlockPos.ZERO, MinecraftClient.getInstance().level);
			activeTemplate.placeInWorld(level, BlockPos.ZERO, BlockPos.ZERO, new StructurePlacementData(), level.random,
										Block.UPDATE_CLIENTS);
			level.createBackup();
			PonderScene scene = compileScene(localization, storyBoard, level);
			scene.begin();
			scenes.add(scene);
		}

		return scenes;
	}

	public static PonderScene compileScene(PonderLocalization localization, StoryBoardEntry sb, @Nullable PonderLevel level) {
		PonderScene scene = new PonderScene(level, localization, sb.getNamespace(), sb.getComponent(), sb.getTags(),
											sb.getOrderingEntries());
		SceneBuilder builder = scene.builder();
		sb.getBoard().program(builder, scene.getSceneBuildingUtil());
		return scene;
	}

	public static StructureTemplate loadSchematic(Identifier location) {
		return loadSchematic(MinecraftClient.getInstance().getResourceManager(), location);
	}

	public static StructureTemplate loadSchematic(ResourceManager resourceManager, Identifier location) {
		String namespace = location.getNamespace();
		String path = "ponder/" + location.getPath() + ".nbt";
		Identifier location1 = new Identifier(namespace, path);

		Optional<Resource> optionalResource = resourceManager.getResource(location1);
		if (optionalResource.isEmpty()) {
			Ponder.LOGGER.error("Ponder schematic missing: " + location1);

			return new StructureTemplate();
		}

		Resource resource = optionalResource.get();
		try (InputStream inputStream = resource.open()) {
			return loadSchematic(inputStream);
		} catch (IOException e) {
			Ponder.LOGGER.error("Failed to read ponder schematic: " + location1, e);
		}

		return new StructureTemplate();
	}

	public static StructureTemplate loadSchematic(InputStream resourceStream) throws IOException {
		StructureTemplate t = new StructureTemplate();
		DataInputStream stream = new DataInputStream(new BufferedInputStream(new GZIPInputStream(resourceStream)));
		NbtCompound nbt = NbtIo.read(stream, new NbtTagSizeTracker(0x20000000L));
		//t.load(Minecraft.getInstance().level.holderLookup(Registries.BLOCK), nbt);
		t.load(BuiltInRegistries.BLOCK.asLookup(), nbt);
		return t;
	}
}
