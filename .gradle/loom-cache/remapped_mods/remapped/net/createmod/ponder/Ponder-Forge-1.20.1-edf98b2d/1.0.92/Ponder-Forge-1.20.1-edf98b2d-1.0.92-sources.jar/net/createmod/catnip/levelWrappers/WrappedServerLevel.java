package net.createmod.catnip.levelWrappers;

import java.util.Collections;
import java.util.List;

import javax.annotation.Nullable;

import net.createmod.ponder.mixin.accessor.EntityAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.map.MapState;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.dimension.DimensionOptions;
import net.minecraft.world.level.ServerWorldProperties;
import net.minecraft.world.tick.WorldTickScheduler;

public class WrappedServerLevel extends ServerWorld {

	protected ServerWorld level;

	public WrappedServerLevel(ServerWorld level) {
		super(level.getServer(), Util.backgroundExecutor(), level.getServer().storageSource,
			  (ServerWorldProperties) level.getLevelData(), level.dimension(),
			  new DimensionOptions(level.dimensionTypeRegistration(), level.getChunkSource().getGenerator()),
			  new DummyStatusListener(), level.isDebug(), level.getBiomeManager().biomeZoomSeed,
			  Collections.emptyList(), false, level.getRandomSequences());
		this.level = level;
	}

	@Override
	public float getSunAngle(float p_72826_1_) {
		return 0;
	}

	@Override
	public int getMaxLocalRawBrightness(BlockPos pos) {
		return 15;
	}

	@Override
	public void sendBlockUpdated(BlockPos pos, BlockState oldState, BlockState newState, int flags) {
		level.sendBlockUpdated(pos, oldState, newState, flags);
	}

	@Override
	public WorldTickScheduler<Block> getBlockTicks() {
		return super.getBlockTicks();
	}

	@Override
	public WorldTickScheduler<Fluid> getFluidTicks() {
		return super.getFluidTicks();
	}

	@Override
	public void levelEvent(@Nullable PlayerEntity player, int type, BlockPos pos, int data) {}

	@Override
	public List<ServerPlayerEntity> players() {
		return Collections.emptyList();
	}

	@Override
	public void playSound(@Nullable PlayerEntity player, double x, double y, double z, SoundEvent soundIn, SoundCategory category,
		float volume, float pitch) {}

	@Override
	public void playSound(@Nullable PlayerEntity p_217384_1_, Entity p_217384_2_, SoundEvent p_217384_3_, SoundCategory p_217384_4_,
		float p_217384_5_, float p_217384_6_) {}

	@Override
	public Entity getEntity(int id) {
		return null;
	}

	@Override
	public MapState getMapData(String mapName) {
		return null;
	}

	@Override
	public boolean addFreshEntity(Entity entityIn) {
		((EntityAccessor) entityIn).catnip$callSetLevel(level);
		return level.addFreshEntity(entityIn);
	}

	@Override
	public void setMapData(String mapId, MapState mapDataIn) {}

	@Override
	public int getFreeMapId() {
		return 0;
	}

	@Override
	public void destroyBlockProgress(int breakerId, BlockPos pos, int progress) {}

	@Override
	public RecipeManager getRecipeManager() {
		return level.getRecipeManager();
	}

	@Override
	public RegistryEntry<Biome> getUncachedNoiseBiome(int p_225604_1_, int p_225604_2_, int p_225604_3_) {
		return level.getUncachedNoiseBiome(p_225604_1_, p_225604_2_, p_225604_3_);
	}



}
